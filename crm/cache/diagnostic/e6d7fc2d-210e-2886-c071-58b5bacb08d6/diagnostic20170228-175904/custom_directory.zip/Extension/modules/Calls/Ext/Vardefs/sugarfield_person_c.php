<?php
 // created: 2015-10-13 08:01:00
$dictionary['Call']['fields']['person_c']['labelValue']='Person';

 ?>