<?php
// created: 2016-05-21 12:01:35
$mod_strings = array (
  'LBL_USER_NAME' => 'AE Name',
  'LBL_TEAMLEADER' => 'Team Leader',
);