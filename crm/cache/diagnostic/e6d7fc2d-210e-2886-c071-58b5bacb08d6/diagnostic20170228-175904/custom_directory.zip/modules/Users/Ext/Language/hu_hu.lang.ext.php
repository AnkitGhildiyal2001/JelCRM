<?php 
 //WARNING: The contents of this file are auto-generated

﻿

$mod_strings['LBL_LIST_NONINHERITABLE'] = "Nem Örökölhető";
$mod_strings['LBL_PRIMARY_GROUP'] = "Elsődleges csoport";


?>