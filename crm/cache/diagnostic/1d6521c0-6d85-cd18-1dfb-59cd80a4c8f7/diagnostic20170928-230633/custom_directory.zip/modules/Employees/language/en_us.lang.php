<?php
// created: 2016-05-21 11:57:59
$mod_strings = array (
  'LBL_TEAMLEADER' => 'Team Leader',
);