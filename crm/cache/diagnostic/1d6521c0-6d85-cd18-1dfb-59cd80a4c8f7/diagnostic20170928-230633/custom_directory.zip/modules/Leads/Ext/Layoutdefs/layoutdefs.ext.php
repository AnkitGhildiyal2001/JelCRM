<?php 
 //WARNING: The contents of this file are auto-generated


// created: 2013-12-12 07:44:12
$layout_defs["Leads"]["subpanel_setup"]["pass1_sendinfopack_leads"] = array (
  'order' => 100,
  'module' => 'pass1_SendInfopack',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_PASS1_SENDINFOPACK_LEADS_FROM_PASS1_SENDINFOPACK_TITLE',
  'get_subpanel_data' => 'pass1_sendinfopack_leads',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);


// created: 2013-12-12 07:44:21
$layout_defs["Leads"]["subpanel_setup"]["pass1_sendinfopack_leads"] = array (
  'order' => 100,
  'module' => 'pass1_SendInfopack',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_PASS1_SENDINFOPACK_LEADS_FROM_PASS1_SENDINFOPACK_TITLE',
  'get_subpanel_data' => 'pass1_sendinfopack_leads',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);


// created: 2013-12-12 07:56:19
$layout_defs["Leads"]["subpanel_setup"]["pass1_sendinfopack_leads"] = array (
  'order' => 100,
  'module' => 'pass1_SendInfopack',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_PASS1_SENDINFOPACK_LEADS_FROM_PASS1_SENDINFOPACK_TITLE',
  'get_subpanel_data' => 'pass1_sendinfopack_leads',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);


// created: 2013-12-12 08:00:31
$layout_defs["Leads"]["subpanel_setup"]["pass1_sendinfopack_leads"] = array (
  'order' => 100,
  'module' => 'pass1_SendInfopack',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_PASS1_SENDINFOPACK_LEADS_FROM_PASS1_SENDINFOPACK_TITLE',
  'get_subpanel_data' => 'pass1_sendinfopack_leads',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);


// created: 2013-12-12 08:01:04
$layout_defs["Leads"]["subpanel_setup"]["pass1_sendinfopack_leads"] = array (
  'order' => 100,
  'module' => 'pass1_SendInfopack',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_PASS1_SENDINFOPACK_LEADS_FROM_PASS1_SENDINFOPACK_TITLE',
  'get_subpanel_data' => 'pass1_sendinfopack_leads',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);


// created: 2013-12-12 09:00:00
$layout_defs["Leads"]["subpanel_setup"]["pass1_sendinfopack_leads"] = array (
  'order' => 100,
  'module' => 'pass1_SendInfopack',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_PASS1_SENDINFOPACK_LEADS_FROM_PASS1_SENDINFOPACK_TITLE',
  'get_subpanel_data' => 'pass1_sendinfopack_leads',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);


// created: 2013-12-12 09:00:04
$layout_defs["Leads"]["subpanel_setup"]["pass1_sendinfopack_leads"] = array (
  'order' => 100,
  'module' => 'pass1_SendInfopack',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_PASS1_SENDINFOPACK_LEADS_FROM_PASS1_SENDINFOPACK_TITLE',
  'get_subpanel_data' => 'pass1_sendinfopack_leads',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);


// created: 2013-12-12 09:07:53
$layout_defs["Leads"]["subpanel_setup"]["pass1_sendinfopack_leads"] = array (
  'order' => 100,
  'module' => 'pass1_SendInfopack',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_PASS1_SENDINFOPACK_LEADS_FROM_PASS1_SENDINFOPACK_TITLE',
  'get_subpanel_data' => 'pass1_sendinfopack_leads',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);


// created: 2013-12-12 09:12:32
$layout_defs["Leads"]["subpanel_setup"]["pass1_sendinfopack_leads"] = array (
  'order' => 100,
  'module' => 'pass1_SendInfopack',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_PASS1_SENDINFOPACK_LEADS_FROM_PASS1_SENDINFOPACK_TITLE',
  'get_subpanel_data' => 'pass1_sendinfopack_leads',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);


// created: 2013-12-12 09:13:06
$layout_defs["Leads"]["subpanel_setup"]["pass1_sendinfopack_leads"] = array (
  'order' => 100,
  'module' => 'pass1_SendInfopack',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_PASS1_SENDINFOPACK_LEADS_FROM_PASS1_SENDINFOPACK_TITLE',
  'get_subpanel_data' => 'pass1_sendinfopack_leads',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);


// created: 2013-12-12 09:13:09
$layout_defs["Leads"]["subpanel_setup"]["pass1_sendinfopack_leads"] = array (
  'order' => 100,
  'module' => 'pass1_SendInfopack',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_PASS1_SENDINFOPACK_LEADS_FROM_PASS1_SENDINFOPACK_TITLE',
  'get_subpanel_data' => 'pass1_sendinfopack_leads',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);


// created: 2013-12-13 06:59:56
$layout_defs["Leads"]["subpanel_setup"]["pass1_sendinfopack_leads"] = array (
  'order' => 100,
  'module' => 'pass1_SendInfopack',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_PASS1_SENDINFOPACK_LEADS_FROM_PASS1_SENDINFOPACK_TITLE',
  'get_subpanel_data' => 'pass1_sendinfopack_leads',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);



 // created: 2014-11-17 08:09:02
$layout_defs["Leads"]["subpanel_setup"]['leads_calls_1'] = array (
  'order' => 100,
  'module' => 'Calls',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_LEADS_CALLS_1_FROM_CALLS_TITLE',
  'get_subpanel_data' => 'leads_calls_1',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);



$layout_defs['Leads']['subpanel_setup']['securitygroups'] = array(
	'top_buttons' => array(array('widget_class' => 'SubPanelTopSelectButton', 'popup_module' => 'SecurityGroups', 'mode' => 'MultiSelect'),),
	'order' => 900,
	'sort_by' => 'name',
	'sort_order' => 'asc',
	'module' => 'SecurityGroups',
	'refresh_page'=>1,
	'subpanel_name' => 'default',
	'get_subpanel_data' => 'SecurityGroups',
	'add_subpanel_data' => 'securitygroup_id',
	'title_key' => 'LBL_SECURITYGROUPS_SUBPANEL_TITLE',
);




?>