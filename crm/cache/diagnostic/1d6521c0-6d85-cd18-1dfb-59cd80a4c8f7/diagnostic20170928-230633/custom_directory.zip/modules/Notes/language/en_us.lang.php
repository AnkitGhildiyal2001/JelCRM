<?php
// created: 2014-10-27 02:48:05
$mod_strings = array (
    'LBL_ACTIVITIES_SUBPANEL_TITLE' => 'Send Infopack',
);