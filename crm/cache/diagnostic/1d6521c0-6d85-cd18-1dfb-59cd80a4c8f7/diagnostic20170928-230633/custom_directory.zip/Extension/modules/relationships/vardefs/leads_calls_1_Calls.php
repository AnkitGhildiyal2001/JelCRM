<?php
// created: 2014-11-17 08:09:02
$dictionary["Call"]["fields"]["leads_calls_1"] = array (
  'name' => 'leads_calls_1',
  'type' => 'link',
  'relationship' => 'leads_calls_1',
  'source' => 'non-db',
  'module' => 'Leads',
  'bean_name' => 'Lead',
  'vname' => 'LBL_LEADS_CALLS_1_FROM_LEADS_TITLE',
);
