<?php
 // created: 2015-10-13 08:08:39
$dictionary['Call']['fields']['status']['default']='todo';
$dictionary['Call']['fields']['status']['comments']='The status of the call (Held, Not Held, etc.)';
$dictionary['Call']['fields']['status']['merge_filter']='disabled';

 ?>