<?php
 // created: 2015-10-13 07:59:05
$dictionary['Call']['fields']['calltime_c']['labelValue']='Call Time';

 ?>