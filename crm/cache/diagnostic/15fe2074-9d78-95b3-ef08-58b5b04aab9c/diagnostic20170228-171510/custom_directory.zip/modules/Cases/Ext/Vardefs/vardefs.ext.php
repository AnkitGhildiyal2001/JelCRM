<?php 
 //WARNING: The contents of this file are auto-generated


 // created: 2016-01-27 09:51:02
$dictionary['Case']['fields']['case_number']['comments']='Visual unique identifier';
$dictionary['Case']['fields']['case_number']['merge_filter']='disabled';
$dictionary['Case']['fields']['case_number']['enable_range_search']=false;
$dictionary['Case']['fields']['case_number']['autoinc_next']='2';
$dictionary['Case']['fields']['case_number']['min']=false;
$dictionary['Case']['fields']['case_number']['max']=false;

 

 // created: 2016-01-27 09:51:13
$dictionary['Case']['fields']['name']['comments']='The short description of the bug';
$dictionary['Case']['fields']['name']['merge_filter']='disabled';

 

 // created: 2016-01-27 09:50:55
$dictionary['Case']['fields']['description']['comments']='Full text of the note';
$dictionary['Case']['fields']['description']['merge_filter']='disabled';

 

 // created: 2016-01-27 09:55:22
$dictionary['Case']['fields']['type']['default']='AutoPartsIndirect';
$dictionary['Case']['fields']['type']['len']=100;
$dictionary['Case']['fields']['type']['options']='type_list';
$dictionary['Case']['fields']['type']['comments']='The type of issue (ex: issue, feature)';
$dictionary['Case']['fields']['type']['merge_filter']='disabled';

 

 // created: 2016-01-27 09:51:20
$dictionary['Case']['fields']['status']['default']='New';
$dictionary['Case']['fields']['status']['comments']='The status of the case';
$dictionary['Case']['fields']['status']['merge_filter']='disabled';

 


$dictionary['Case']['fields']['SecurityGroups'] = array (
  	'name' => 'SecurityGroups',
    'type' => 'link',
	'relationship' => 'securitygroups_cases',
	'module'=>'SecurityGroups',
	'bean_name'=>'SecurityGroup',
    'source'=>'non-db',
	'vname'=>'LBL_SECURITYGROUPS',
);





?>