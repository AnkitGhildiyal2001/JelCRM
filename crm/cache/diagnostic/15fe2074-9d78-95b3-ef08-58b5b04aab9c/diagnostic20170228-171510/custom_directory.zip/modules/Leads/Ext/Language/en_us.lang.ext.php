<?php 
 //WARNING: The contents of this file are auto-generated


//THIS FILE IS AUTO GENERATED, DO NOT MODIFY
$mod_strings['LBL_SEND_SENDINFOPACK_LEADS_1_FROM_SEND_SENDINFOPACK_TITLE'] = 'send infopack';

 
 // created: 2014-10-20 01:17:08
$mod_strings['LBL_CASES'] = 'Cases';
$mod_strings['LBL_PASS1_SENDINFOPACK_LEADS_FROM_PASS1_SENDINFOPACK_TITLE'] = 'Send Info Pack';
$mod_strings['LBL_CLAIMFILINGNUMBER'] = 'Claim Filing Status';




//THIS FILE IS AUTO GENERATED, DO NOT MODIFY
$mod_strings['LBL_PASS1_SENDINFOPACK_LEADS_FROM_PASS1_SENDINFOPACK_TITLE'] = 'Send Infopack';


//THIS FILE IS AUTO GENERATED, DO NOT MODIFY
$mod_strings['LBL_SEND_SENDINFOPACK_LEADS_1_FROM_SEND_SENDINFOPACK_TITLE'] = 'send infopack';
$mod_strings['LBL_LEADS_CALLS_1_FROM_CALLS_TITLE'] = 'Calls';



$mod_strings['LBL_SECURITYGROUPS_SUBPANEL_TITLE'] = "Security Groups";

?>