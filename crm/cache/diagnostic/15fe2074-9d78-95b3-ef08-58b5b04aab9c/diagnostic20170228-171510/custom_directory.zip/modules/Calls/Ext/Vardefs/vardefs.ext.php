<?php 
 //WARNING: The contents of this file are auto-generated


// created: 2014-11-17 08:09:02
$dictionary["Call"]["fields"]["leads_calls_1"] = array (
  'name' => 'leads_calls_1',
  'type' => 'link',
  'relationship' => 'leads_calls_1',
  'source' => 'non-db',
  'module' => 'Leads',
  'bean_name' => 'Lead',
  'vname' => 'LBL_LEADS_CALLS_1_FROM_LEADS_TITLE',
);



$dictionary['Call']['fields']['SecurityGroups'] = array (
  	'name' => 'SecurityGroups',
    'type' => 'link',
	'relationship' => 'securitygroups_calls',
	'module'=>'SecurityGroups',
	'bean_name'=>'SecurityGroup',
    'source'=>'non-db',
	'vname'=>'LBL_SECURITYGROUPS',
);






 // created: 2015-10-13 08:08:39
$dictionary['Call']['fields']['status']['default']='todo';
$dictionary['Call']['fields']['status']['comments']='The status of the call (Held, Not Held, etc.)';
$dictionary['Call']['fields']['status']['merge_filter']='disabled';

 

 // created: 2015-10-13 08:01:00
$dictionary['Call']['fields']['person_c']['labelValue']='Person';

 

 // created: 2015-10-13 07:59:05
$dictionary['Call']['fields']['calltime_c']['labelValue']='Call Time';

 

 // created: 2015-10-13 07:57:20
$dictionary['Call']['fields']['calldate_c']['labelValue']='Call Date';

 
?>