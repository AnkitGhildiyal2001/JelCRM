<?php 
 //WARNING: The contents of this file are auto-generated



$mod_strings['LBL_LIST_NONINHERITABLE'] = "Não Herdável";
$mod_strings['LBL_PRIMARY_GROUP'] = "Grupo Principal";


?>