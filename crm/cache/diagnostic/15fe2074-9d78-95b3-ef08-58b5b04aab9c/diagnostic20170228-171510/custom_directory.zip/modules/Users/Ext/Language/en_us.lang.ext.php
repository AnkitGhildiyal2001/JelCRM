<?php 
 //WARNING: The contents of this file are auto-generated


//THIS FILE IS AUTO GENERATED, DO NOT MODIFY
$mod_strings['LBL_USERS_USERS_1_FROM_USERS_L_TITLE'] = 'Team Leader';
$mod_strings['LBL_USERS_USERS_1_FROM_USERS_R_TITLE'] = 'Users';



$mod_strings['LBL_LIST_NONINHERITABLE'] = "Not Inheritable";
$mod_strings['LBL_PRIMARY_GROUP'] = "Primary Group";

?>