<?php 
 //WARNING: The contents of this file are auto-generated

 
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

global $current_language, $app_strings, $current_user;
$sg_mod_strings = return_module_language($current_language, 'SecurityGroups');
$module_menu[] = Array("index.php?module=SecurityGroups&action=EditView&return_module=SecurityGroups&return_action=DetailView", $sg_mod_strings['LNK_NEW_RECORD'],"SecurityGroups");
$module_menu[] = Array("index.php?module=SecurityGroups&action=ListView&return_module=SecurityGroups&return_action=ListView", $sg_mod_strings['LBL_LIST_FORM_TITLE'],"SecurityGroups");

if(is_admin($current_user)) {
	global $current_language;
	$admin_mod_strings = return_module_language($current_language, 'Administration');
	//$module_menu[] = Array("index.php?module=Users&action=index&return_module=SecurityGroups&return_action=ListView", $admin_mod_strings['LBL_MANAGE_USERS_TITLE'],"Users");
	$module_menu[] = Array("index.php?module=ACLRoles&action=index&return_module=SecurityGroups&return_action=ListView", $admin_mod_strings['LBL_MANAGE_ROLES_TITLE'],"ACLRoles");
	$module_menu[] = Array("index.php?module=SecurityGroups&action=config&return_module=SecurityGroups&return_action=ListView", $admin_mod_strings['LBL_CONFIG_SECURITYGROUPS_TITLE'],"SecurityGroups");
	

}


 
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

global $current_language, $app_strings, $current_user;

if(is_admin($current_user)) {

    if(!empty($_REQUEST['record'])) {
        require_once('modules/Users/User.php');
        $log_user = new User();
        $log_user->retrieve($_REQUEST['record']);
        $module_menu[] = Array("index.php?module=Users&action=Masquerade&record=".$_REQUEST['record'], $app_strings['LBL_LOGIN_AS'].$log_user->user_name,"Masquerade");
    }

    else {
        //free only
        $module_menu[] = Array("index.php?module=Users&action=Masquerade", $app_strings['LBL_LOGIN_AS'],"Masquerade");
    }

}


?>