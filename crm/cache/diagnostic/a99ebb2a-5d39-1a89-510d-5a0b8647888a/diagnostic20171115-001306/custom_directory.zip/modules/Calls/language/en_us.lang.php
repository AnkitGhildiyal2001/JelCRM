<?php
// created: 2015-10-13 08:34:50
$mod_strings = array (
  'LBL_DATE' => 'Call Date/Time',
  'LBL_CALLDATE' => 'Call Date',
  'LBL_CALLTIME' => 'Call Time',
  'LBL_PERSON' => 'Person',
  'LBL_STATUS' => 'Status:',
  'LBL_LIST_DATE' => 'Call Date/Time',
);