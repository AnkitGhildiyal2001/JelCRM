<?php
// created: 2014-11-17 08:09:02
$dictionary["Lead"]["fields"]["leads_calls_1"] = array (
  'name' => 'leads_calls_1',
  'type' => 'link',
  'relationship' => 'leads_calls_1',
  'source' => 'non-db',
  'module' => 'Calls',
  'bean_name' => 'Call',
  'vname' => 'LBL_LEADS_CALLS_1_FROM_CALLS_TITLE',
);
