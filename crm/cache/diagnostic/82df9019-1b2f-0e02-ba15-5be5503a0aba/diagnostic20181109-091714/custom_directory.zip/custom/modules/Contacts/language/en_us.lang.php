<?php
// created: 2015-08-21 13:50:24
$mod_strings = array (
  'LBL_LIST_NAME' => 'Contact Name',
  'LBL_ASSIGNED_TO_ID' => 'Assigned AE',
  'LBL_FIRST_NAME' => 'Contact First Name:',
  'LBL_LAST_NAME' => 'Contact Last Name:',
  'LBL_LIST_ASSIGNED_USER' => 'AE',
);