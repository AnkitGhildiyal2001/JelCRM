<?php 
 //WARNING: The contents of this file are auto-generated



$mod_strings['LBL_SECURITYGROUPS'] = 'Фільтр по Групам Користувачів';


?>