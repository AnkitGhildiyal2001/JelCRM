<?php 
 //WARNING: The contents of this file are auto-generated


//THIS FILE IS AUTO GENERATED, DO NOT MODIFY
$mod_strings['LBL_LEADS_CALLS_1_FROM_LEADS_TITLE'] = 'Leads';



$mod_strings['LBL_SECURITYGROUPS_SUBPANEL_TITLE'] = "Security Groups";

?>