<?php
// created: 2016-01-27 09:55:22
$mod_strings = array (
  'LBL_CREATED_USER' => 'CreatedAE',
  'LBL_DESCRIPTION' => 'Description:',
  'LBL_NUMBER' => 'Number:',
  'LBL_SUBJECT' => 'Subject:',
  'LBL_STATUS' => 'Status:',
  'LBL_TYPE' => 'Type',
);