<?php 
 //WARNING: The contents of this file are auto-generated



$mod_strings['LBL_MANAGE_SECURITYGROUPS_TITLE'] = "Gestione Gruppi di SecuritySuite";
$mod_strings['LBL_MANAGE_SECURITYGROUPS'] = "Editor Gruppi di SecuritySuite.";
$mod_strings['LBL_SECURITYGROUPS'] = "SecuritySuite";
$mod_strings['LBL_CONFIG_SECURITYGROUPS_TITLE'] = "Impostazioni di SecuritySuite";
$mod_strings['LBL_CONFIG_SECURITYGROUPS'] = "Configura le impostazioni di SecuritySuite come ereditarieta` dei gruppi, sicurezza aggiunta, etc.";
$mod_strings['LBL_SECURITYGROUPS'] = "SecuritySuite";
$mod_strings['LBL_SECURITYGROUPS_UPGRADE_INFO_TITLE'] = "Ottenere tutte le caratteristiche!";
$mod_strings['LBL_SECURITYGROUPS_UPGRADE_INFO'] = "Inizia beneficiando delle molte caratteristiche che SecuritySuite Premium vengono con incluso il debugging veloce, layout di gruppo personalizzato, e altro ancora.";
$mod_strings['LBL_SECURITYGROUPS_INFO_TITLE'] = "Documentazione";
$mod_strings['LBL_SECURITYGROUPS_INFO'] = "Ulteriori informazioni sulle molte caratteristiche e opzioni che SecuritySuite viene imballato con.";
$mod_strings['LBL_SECURITYGROUPS_DASHLETPUSH_TITLE'] = "Forza pubblicazione Dashlet dei Messaggi";
$mod_strings['LBL_SECURITYGROUPS_DASHLETPUSH'] = "Pubblica la Dashlet dei Messaggi nell'Home Page di tutti gli utenti. Questo processo potrebbe richiedere del tempo in base al numero degli utenti.";
$mod_strings['LBL_SECURITYGROUPS_HOOKUP_TITLE'] = "Modulo per l'Integrazione";
$mod_strings['LBL_SECURITYGROUPS_HOOKUP'] = "Integra Security Suite con i tuoi moduli custom.";
$mod_strings['LBL_SECURITYGROUPS_SUGAROUTFITTERS_TITLE'] = "SugarOutfitters.com";
$mod_strings['LBL_SECURITYGROUPS_SUGAROUTFITTERS'] = "Vedere soluzioni pi� selezionati con cura per Community Edition.";
$mod_strings['LBL_SECURITYGROUPS_LICENSE_TITLE'] = 'Configurazione License';
$mod_strings['LBL_SECURITYGROUPS_LICENSE'] = 'Gestire e configurare la licenza per questo componente aggiuntivo';

?>