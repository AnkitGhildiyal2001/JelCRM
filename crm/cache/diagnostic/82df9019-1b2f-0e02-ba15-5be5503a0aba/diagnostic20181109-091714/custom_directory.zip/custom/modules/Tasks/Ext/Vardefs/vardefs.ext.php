<?php 
 //WARNING: The contents of this file are auto-generated



//DEG: 21-Oct-2016
$dictionary['Task']['fields']['assigned_user_name']['value']='Christine Appleyard';
$dictionary['Task']['fields']['assigned_user_id']['value']='4b7a3db9-26c0-cfad-9482-56defd33ca80';
$dictionary['Task']['fields']['description']['default']='Please send the Infopack';
//////////////////




$dictionary['Task']['fields']['SecurityGroups'] = array (
  	'name' => 'SecurityGroups',
    'type' => 'link',
	'relationship' => 'securitygroups_tasks',
	'module'=>'SecurityGroups',
	'bean_name'=>'SecurityGroup',
    'source'=>'non-db',
	'vname'=>'LBL_SECURITYGROUPS',
);





?>