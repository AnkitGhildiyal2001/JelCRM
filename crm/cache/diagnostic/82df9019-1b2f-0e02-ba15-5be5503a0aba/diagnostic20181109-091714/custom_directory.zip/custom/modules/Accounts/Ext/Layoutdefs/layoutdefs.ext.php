<?php 
 //WARNING: The contents of this file are auto-generated




$layout_defs['Accounts']['subpanel_setup']['securitygroups'] = array(
	'top_buttons' => array(array('widget_class' => 'SubPanelTopSelectButton', 'popup_module' => 'SecurityGroups', 'mode' => 'MultiSelect'),),
	'order' => 900,
	'sort_by' => 'name',
	'sort_order' => 'asc',
	'module' => 'SecurityGroups',
	'refresh_page'=>1,
	'subpanel_name' => 'default',
	'get_subpanel_data' => 'SecurityGroups',
	'add_subpanel_data' => 'securitygroup_id',
	'title_key' => 'LBL_SECURITYGROUPS_SUBPANEL_TITLE',
);






// created: 2013-12-12 07:18:15
$layout_defs["Accounts"]["subpanel_setup"]["pass1_sendiopack_accounts"] = array (
  'order' => 100,
  'module' => 'pass1_SendInfopack',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_PASS1_SENDINFOPACK_ACCOUNTS_FROM_PASS1_SENDINFOPACK_TITLE',
  'get_subpanel_data' => 'pass1_sendiopack_accounts',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);


// created: 2013-12-12 07:28:34
$layout_defs["Accounts"]["subpanel_setup"]["pass1_sendiopack_accounts"] = array (
  'order' => 100,
  'module' => 'pass1_SendInfopack',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_PASS1_SENDINFOPACK_ACCOUNTS_FROM_PASS1_SENDINFOPACK_TITLE',
  'get_subpanel_data' => 'pass1_sendiopack_accounts',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);


// created: 2013-12-12 07:33:49
$layout_defs["Accounts"]["subpanel_setup"]["pass1_sendiopack_accounts"] = array (
  'order' => 100,
  'module' => 'pass1_SendInfopack',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_PASS1_SENDINFOPACK_ACCOUNTS_FROM_PASS1_SENDINFOPACK_TITLE',
  'get_subpanel_data' => 'pass1_sendiopack_accounts',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);


// created: 2013-12-12 07:33:56
$layout_defs["Accounts"]["subpanel_setup"]["pass1_sendiopack_accounts"] = array (
  'order' => 100,
  'module' => 'pass1_SendInfopack',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_PASS1_SENDINFOPACK_ACCOUNTS_FROM_PASS1_SENDINFOPACK_TITLE',
  'get_subpanel_data' => 'pass1_sendiopack_accounts',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);


// created: 2013-12-12 07:44:12
$layout_defs["Accounts"]["subpanel_setup"]["pass1_sendiopack_accounts"] = array (
  'order' => 100,
  'module' => 'pass1_SendInfopack',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_PASS1_SENDINFOPACK_ACCOUNTS_FROM_PASS1_SENDINFOPACK_TITLE',
  'get_subpanel_data' => 'pass1_sendiopack_accounts',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);


// created: 2013-12-12 07:44:21
$layout_defs["Accounts"]["subpanel_setup"]["pass1_sendiopack_accounts"] = array (
  'order' => 100,
  'module' => 'pass1_SendInfopack',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_PASS1_SENDINFOPACK_ACCOUNTS_FROM_PASS1_SENDINFOPACK_TITLE',
  'get_subpanel_data' => 'pass1_sendiopack_accounts',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);


// created: 2013-12-12 07:56:19
$layout_defs["Accounts"]["subpanel_setup"]["pass1_sendiopack_accounts"] = array (
  'order' => 100,
  'module' => 'pass1_SendInfopack',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_PASS1_SENDINFOPACK_ACCOUNTS_FROM_PASS1_SENDINFOPACK_TITLE',
  'get_subpanel_data' => 'pass1_sendiopack_accounts',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);


// created: 2013-12-12 08:00:31
$layout_defs["Accounts"]["subpanel_setup"]["pass1_sendiopack_accounts"] = array (
  'order' => 100,
  'module' => 'pass1_SendInfopack',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_PASS1_SENDINFOPACK_ACCOUNTS_FROM_PASS1_SENDINFOPACK_TITLE',
  'get_subpanel_data' => 'pass1_sendiopack_accounts',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);


// created: 2013-12-12 08:01:04
$layout_defs["Accounts"]["subpanel_setup"]["pass1_sendiopack_accounts"] = array (
  'order' => 100,
  'module' => 'pass1_SendInfopack',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_PASS1_SENDINFOPACK_ACCOUNTS_FROM_PASS1_SENDINFOPACK_TITLE',
  'get_subpanel_data' => 'pass1_sendiopack_accounts',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);


// created: 2013-12-12 09:00:00
$layout_defs["Accounts"]["subpanel_setup"]["pass1_sendiopack_accounts"] = array (
  'order' => 100,
  'module' => 'pass1_SendInfopack',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_PASS1_SENDINFOPACK_ACCOUNTS_FROM_PASS1_SENDINFOPACK_TITLE',
  'get_subpanel_data' => 'pass1_sendiopack_accounts',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);


// created: 2013-12-12 09:00:04
$layout_defs["Accounts"]["subpanel_setup"]["pass1_sendiopack_accounts"] = array (
  'order' => 100,
  'module' => 'pass1_SendInfopack',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_PASS1_SENDINFOPACK_ACCOUNTS_FROM_PASS1_SENDINFOPACK_TITLE',
  'get_subpanel_data' => 'pass1_sendiopack_accounts',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);


// created: 2013-12-12 09:07:53
$layout_defs["Accounts"]["subpanel_setup"]["pass1_sendiopack_accounts"] = array (
  'order' => 100,
  'module' => 'pass1_SendInfopack',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_PASS1_SENDINFOPACK_ACCOUNTS_FROM_PASS1_SENDINFOPACK_TITLE',
  'get_subpanel_data' => 'pass1_sendiopack_accounts',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);


// created: 2013-12-12 09:12:32
$layout_defs["Accounts"]["subpanel_setup"]["pass1_sendiopack_accounts"] = array (
  'order' => 100,
  'module' => 'pass1_SendInfopack',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_PASS1_SENDINFOPACK_ACCOUNTS_FROM_PASS1_SENDINFOPACK_TITLE',
  'get_subpanel_data' => 'pass1_sendiopack_accounts',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);


// created: 2013-12-12 09:13:06
$layout_defs["Accounts"]["subpanel_setup"]["pass1_sendiopack_accounts"] = array (
  'order' => 100,
  'module' => 'pass1_SendInfopack',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_PASS1_SENDINFOPACK_ACCOUNTS_FROM_PASS1_SENDINFOPACK_TITLE',
  'get_subpanel_data' => 'pass1_sendiopack_accounts',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);


// created: 2013-12-12 09:13:09
$layout_defs["Accounts"]["subpanel_setup"]["pass1_sendiopack_accounts"] = array (
  'order' => 100,
  'module' => 'pass1_SendInfopack',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_PASS1_SENDINFOPACK_ACCOUNTS_FROM_PASS1_SENDINFOPACK_TITLE',
  'get_subpanel_data' => 'pass1_sendiopack_accounts',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);


// created: 2013-12-13 06:59:56
$layout_defs["Accounts"]["subpanel_setup"]["pass1_sendiopack_accounts"] = array (
  'order' => 100,
  'module' => 'pass1_SendInfopack',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_PASS1_SENDINFOPACK_ACCOUNTS_FROM_PASS1_SENDINFOPACK_TITLE',
  'get_subpanel_data' => 'pass1_sendiopack_accounts',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);



//auto-generated file DO NOT EDIT
$layout_defs['Accounts']['subpanel_setup']['contacts']['override_subpanel_name'] = 'Account_subpanel_contacts';


//auto-generated file DO NOT EDIT
$layout_defs['Accounts']['subpanel_setup']['leads']['override_subpanel_name'] = 'Account_subpanel_leads';

?>