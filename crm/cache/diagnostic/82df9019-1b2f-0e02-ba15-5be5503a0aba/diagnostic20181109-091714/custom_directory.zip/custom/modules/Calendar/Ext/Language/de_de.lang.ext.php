<?php 
 //WARNING: The contents of this file are auto-generated



$mod_strings['LBL_SECURITYGROUPS'] = 'Benutzerliste nach Berechtigungsgruppen filtern';

?>