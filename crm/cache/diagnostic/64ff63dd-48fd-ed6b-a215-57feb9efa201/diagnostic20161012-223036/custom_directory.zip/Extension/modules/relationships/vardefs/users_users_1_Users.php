<?php
// created: 2016-05-21 11:59:16
$dictionary["User"]["fields"]["users_users_1"] = array (
  'name' => 'users_users_1',
  'type' => 'link',
  'relationship' => 'users_users_1',
  'source' => 'non-db',
  'module' => 'Users',
  'bean_name' => 'User',
  'vname' => 'LBL_USERS_USERS_1_FROM_USERS_L_TITLE',
);
$dictionary["User"]["fields"]["users_users_1"] = array (
  'name' => 'users_users_1',
  'type' => 'link',
  'relationship' => 'users_users_1',
  'source' => 'non-db',
  'module' => 'Users',
  'bean_name' => 'User',
  'vname' => 'LBL_USERS_USERS_1_FROM_USERS_R_TITLE',
);
