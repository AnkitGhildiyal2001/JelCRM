<?php
 // created: 2015-10-13 07:57:20
$dictionary['Call']['fields']['calldate_c']['labelValue']='Call Date';

 ?>