<?php

$mod_strings['LBL_DEFAULT'] = 'Standard';
$mod_strings['LBL_ADD_LAYOUT'] = 'Layout hinzufügen';
$mod_strings['LBL_ADD_LAYOUTS'] = 'Layout hinzufügen';
$mod_strings['LBL_QUESTION_ADD_LAYOUT'] = 'Wählen Sie ein Gruppen Layout zum Hinzufügen';
$mod_strings['LBL_REMOVE_LAYOUT'] = 'Gruppen Layout entfernen';

$mod_strings['LBL_SECURITYGROUP'] = 'Berechtigungsgruppe:';
$mod_strings['LBL_COPY_FROM'] = 'Kopieren von:';
$mod_strings['LBL_ADDLAYOUTDONE'] = 'Layout gespeichert';
$mod_strings['LBL_REMOVELAYOUTDONE'] = 'Layout entfernt';
$mod_strings['LBL_REMOVE_CONFIRM'] = 'Sind Sie sicher?';
$mod_strings['help']['studioWizard']['addLayoutHelp'] = "Um ein spezielles Layout für eine Berechtigungsgruppe zu erstellen, wählen Sie die Gruppe und ein Layout als Ausgangspunkt für Ihre Anpassung";
$mod_strings['LBL_ADD_GROUP_LAYOUT'] = 'In einer Berechtigungsgruppe Layout';
