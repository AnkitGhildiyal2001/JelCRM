<?php
// created: 2016-04-12 14:30:53
$GLOBALS['tabStructure'] = array (
  'LBL_TABGROUP_SALES' => 
  array (
    'label' => 'LBL_TABGROUP_SALES',
    'modules' => 
    array (
      0 => 'Home',
      1 => 'Leads',
      2 => 'Accounts',
      3 => 'Contacts',
      4 => 'Documents',
      5 => 'Calls',
      6 => 'Calendar',
      7 => 'Meetings',
      8 => 'Tasks',
      9 => 'Notes',
    ),
  ),
);