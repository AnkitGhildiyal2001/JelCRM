<?php 
 //WARNING: The contents of this file are auto-generated


 // created: 2016-03-30 20:55:57
$dictionary['Account']['fields']['contactname_c']['labelValue']='Contact Name';

 

 // created: 2015-08-22 13:07:24
$dictionary['Account']['fields']['accountnumber_c']['labelValue']='Account Number';

 

 // created: 2015-08-22 13:36:38
$dictionary['Account']['fields']['billing_address_street']['comments']='The street address used for billing address';
$dictionary['Account']['fields']['billing_address_street']['merge_filter']='disabled';

 

 // created: 2014-10-20 07:58:03
$dictionary['Account']['fields']['companyname_c']['labelValue']='Company Name';

 

 // created: 2015-08-22 13:50:11
$dictionary['Account']['fields']['name']['comments']='';
$dictionary['Account']['fields']['name']['merge_filter']='disabled';
$dictionary['Account']['fields']['name']['default']='';
$dictionary['Account']['fields']['name']['required']=false;
$dictionary['Account']['fields']['name']['audited']=false;

 

 // created: 2014-10-20 07:58:02
$dictionary['Account']['fields']['claimfilingstatus_c']['labelValue']='Claim Filing Status';

 

 // created: 2014-10-20 07:58:02
$dictionary['Account']['fields']['casem_c']['labelValue']='Casem';

 

 // created: 2016-04-07 14:21:46
$dictionary['Account']['fields']['sic_code']['comments']='SIC code of the account';
$dictionary['Account']['fields']['sic_code']['importable']='false';
$dictionary['Account']['fields']['sic_code']['merge_filter']='disabled';

 

 // created: 2014-10-20 07:58:02
$dictionary['Account']['fields']['claimstatus_c']['labelValue']='Claim Status';

 

 // created: 2014-10-20 07:58:03
$dictionary['Account']['fields']['phone_work_c']['labelValue']='phone work';

 

 // created: 2016-04-07 14:22:10
$dictionary['Account']['fields']['ticker_symbol']['comments']='The stock trading (ticker) symbol for the company';
$dictionary['Account']['fields']['ticker_symbol']['importable']='false';
$dictionary['Account']['fields']['ticker_symbol']['merge_filter']='disabled';

 

 // created: 2015-08-22 12:56:32
$dictionary['Account']['fields']['last_name_c']['labelValue']='Contact\'s Last Name';

 

 // created: 2015-08-22 12:55:07
$dictionary['Account']['fields']['otherlastname_c']['labelValue']='Signer\'s Last Name';

 

 // created: 2016-10-07 15:12:19
$dictionary['Account']['fields']['taxid_c']['labelValue']='TaxID';

 

 // created: 2015-08-22 13:08:18
$dictionary['Account']['fields']['first_name_c']['labelValue']='Contact\'s First Name';

 

 // created: 2014-10-20 07:58:03
$dictionary['Account']['fields']['estclaim_c']['labelValue']='Est Claim';

 

 // created: 2014-10-20 07:58:03
$dictionary['Account']['fields']['phone_mobile_c']['labelValue']='phone mobile';

 

 // created: 2015-08-22 12:53:25
$dictionary['Account']['fields']['otherfirstname_c']['labelValue']='Signer First Name';

 

 // created: 2016-04-07 14:22:23
$dictionary['Account']['fields']['rating']['comments']='An arbitrary rating for this company for use in comparisons with others';
$dictionary['Account']['fields']['rating']['importable']='false';
$dictionary['Account']['fields']['rating']['merge_filter']='disabled';

 

// created: 2013-12-13 06:59:56
$dictionary["Account"]["fields"]["pass1_sendiopack_accounts"] = array (
  'name' => 'pass1_sendiopack_accounts',
  'type' => 'link',
  'relationship' => 'pass1_sendinfopack_accounts',
  'source' => 'non-db',
  'vname' => 'LBL_PASS1_SENDINFOPACK_ACCOUNTS_FROM_PASS1_SENDINFOPACK_TITLE',
);



$dictionary['Account']['fields']['SecurityGroups'] = array (
  	'name' => 'SecurityGroups',
    'type' => 'link',
	'relationship' => 'securitygroups_accounts',
	'module'=>'SecurityGroups',
	'bean_name'=>'SecurityGroup',
    'source'=>'non-db',
	'vname'=>'LBL_SECURITYGROUPS',
);





?>