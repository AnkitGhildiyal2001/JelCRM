<?php
// created: 2014-09-15 13:05:15
$modules_sources = array (
  'Accounts' => 
  array (
    'ext_rest_insideview' => 'ext_rest_insideview',
  ),
  'Contacts' => 
  array (
    'ext_rest_insideview' => 'ext_rest_insideview',
  ),
  'Leads' => 
  array (
    'ext_rest_insideview' => 'ext_rest_insideview',
  ),
  'Prospects' => 
  array (
  ),
  'Opportunities' => 
  array (
    'ext_rest_insideview' => 'ext_rest_insideview',
  ),
);