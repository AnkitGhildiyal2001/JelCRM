<?php 
 //WARNING: The contents of this file are auto-generated


// created: 2013-12-13 06:59:56
$dictionary["Lead"]["fields"]["pass1_sendinfopack_leads"] = array (
  'name' => 'pass1_sendinfopack_leads',
  'type' => 'link',
  'relationship' => 'pass1_sendinfopack_leads',
  'source' => 'non-db',
  'vname' => 'LBL_PASS1_SENDINFOPACK_LEADS_FROM_PASS1_SENDINFOPACK_TITLE',
);



$dictionary['Lead']['fields']['SecurityGroups'] = array (
  	'name' => 'SecurityGroups',
    'type' => 'link',
	'relationship' => 'securitygroups_leads',
	'module'=>'SecurityGroups',
	'bean_name'=>'SecurityGroup',
    'source'=>'non-db',
	'vname'=>'LBL_SECURITYGROUPS',
);






 // created: 2016-05-26 12:29:08
$dictionary['Lead']['fields']['primary_address_state']['required']=false;
$dictionary['Lead']['fields']['primary_address_state']['audited']=true;
$dictionary['Lead']['fields']['primary_address_state']['comments']='State for primary address';
$dictionary['Lead']['fields']['primary_address_state']['merge_filter']='disabled';

 

 // created: 2014-10-20 08:24:55
$dictionary['Lead']['fields']['claimfilingnumber_c']['labelValue']='Claim Filing Status';

 

 // created: 2015-08-22 11:26:16
$dictionary['Lead']['fields']['last_name']['audited']=true;
$dictionary['Lead']['fields']['last_name']['comments']='Last name of the contact';
$dictionary['Lead']['fields']['last_name']['merge_filter']='disabled';

 

 // created: 2015-08-22 11:24:19
$dictionary['Lead']['fields']['companyname_c']['labelValue']='Company Name';

 

 // created: 2016-05-26 12:24:33
$dictionary['Lead']['fields']['dbaname_c']['labelValue']='DBA Name';

 

 // created: 2016-05-26 12:22:04
$dictionary['Lead']['fields']['primary_address_city']['required']=false;
$dictionary['Lead']['fields']['primary_address_city']['audited']=true;
$dictionary['Lead']['fields']['primary_address_city']['comments']='City for primary address';
$dictionary['Lead']['fields']['primary_address_city']['merge_filter']='disabled';

 

 // created: 2014-10-27 02:48:05
$dictionary['Lead']['fields']['multilocation_c']['labelValue']='Multi Location';

 

 // created: 2014-10-27 02:38:16
$dictionary['Lead']['fields']['taxid_c']['labelValue']='TAXID';

 

 // created: 2014-10-27 02:43:48
$dictionary['Lead']['fields']['multitaxid_c']['labelValue']='Multi Taxid';

 

 // created: 2016-05-26 12:28:57
$dictionary['Lead']['fields']['primary_address_street']['required']=false;
$dictionary['Lead']['fields']['primary_address_street']['audited']=true;
$dictionary['Lead']['fields']['primary_address_street']['comments']='Street address for primary address';
$dictionary['Lead']['fields']['primary_address_street']['merge_filter']='disabled';

 

 // created: 2016-05-26 12:22:34
$dictionary['Lead']['fields']['primary_address_postalcode']['required']=false;
$dictionary['Lead']['fields']['primary_address_postalcode']['audited']=true;
$dictionary['Lead']['fields']['primary_address_postalcode']['comments']='Postal code for primary address';
$dictionary['Lead']['fields']['primary_address_postalcode']['merge_filter']='disabled';

 

 // created: 2015-08-22 11:26:46
$dictionary['Lead']['fields']['phone_work']['required']=true;
$dictionary['Lead']['fields']['phone_work']['comments']='Work phone number of the contact';
$dictionary['Lead']['fields']['phone_work']['merge_filter']='disabled';

 

 // created: 2015-08-22 11:26:07
$dictionary['Lead']['fields']['first_name']['required']=true;
$dictionary['Lead']['fields']['first_name']['audited']=true;
$dictionary['Lead']['fields']['first_name']['comments']='First name of the contact';
$dictionary['Lead']['fields']['first_name']['merge_filter']='disabled';

 

 // created: 2014-10-27 02:46:41
$dictionary['Lead']['fields']['altsignertitle_c']['labelValue']='Signer Title';

 

// created: 2014-11-17 08:09:02
$dictionary["Lead"]["fields"]["leads_calls_1"] = array (
  'name' => 'leads_calls_1',
  'type' => 'link',
  'relationship' => 'leads_calls_1',
  'source' => 'non-db',
  'module' => 'Calls',
  'bean_name' => 'Call',
  'vname' => 'LBL_LEADS_CALLS_1_FROM_CALLS_TITLE',
);


 // created: 2016-05-26 12:24:44
$dictionary['Lead']['fields']['email1']['required']=true;
$dictionary['Lead']['fields']['email1']['audited']=true;
$dictionary['Lead']['fields']['email1']['merge_filter']='disabled';

 

 // created: 2016-07-27 13:24:59
$dictionary['Lead']['fields']['cases_c']['labelValue']='Cases';

 
?>