<?php 
 //WARNING: The contents of this file are auto-generated



//DEG: 21-Oct-2016
$dictionary['Task']['fields']['assigned_user_name']['value'] = 'Christine Appleyard';
$dictionary['Task']['fields']['assigned_user_id']['value'] = '4b7a3db9-26c0-cfad-9482-56defd33ca80';
$dictionary['Task']['fields']['description']['default'] = 'Please send the Infopack';
//////////////////


 // created: 2019-11-02 23:18:45
$dictionary['Task']['fields']['companyname_c']['inline_edit']='1';
$dictionary['Task']['fields']['companyname_c']['labelValue']='Company Legal Name';

 
?>