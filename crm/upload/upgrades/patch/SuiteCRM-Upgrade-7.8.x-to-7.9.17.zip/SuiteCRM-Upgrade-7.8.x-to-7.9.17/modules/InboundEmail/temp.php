<?php
/**
 * Stub for certain interactions;
 */
class temp {
    public $name;
}
