<?php
if (!defined('sugarEntry') || !sugarEntry) {
    die('Not A Valid Entry Point');
}

$suitecrm_version      = '7.9.17';
$suitecrm_timestamp    = '2018-04-03 17:00:00';
