<?php
/**
 *
 * SugarCRM Community Edition is a customer relationship management program developed by
 * SugarCRM, Inc. Copyright (C) 2004-2013 SugarCRM Inc.
 *
 * SuiteCRM is an extension to SugarCRM Community Edition developed by SalesAgility Ltd.
 * Copyright (C) 2011 - 2017 SalesAgility Ltd.
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by the
 * Free Software Foundation with the addition of the following permission added
 * to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED WORK
 * IN WHICH THE COPYRIGHT IS OWNED BY SUGARCRM, SUGARCRM DISCLAIMS THE WARRANTY
 * OF NON INFRINGEMENT OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU Affero General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License along with
 * this program; if not, see http://www.gnu.org/licenses or write to the Free
 * Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
 * 02110-1301 USA.
 *
 * You can contact SugarCRM, Inc. headquarters at 10050 North Wolfe Road,
 * SW2-130, Cupertino, CA 95014, USA. or at email address contact@sugarcrm.com.
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License version 3,
 * these Appropriate Legal Notices must retain the display of the "Powered by
 * SugarCRM" logo and "Supercharged by SuiteCRM" logo. If the display of the logos is not
 * reasonably feasible for  technical reasons, the Appropriate Legal Notices must
 * display the words  "Powered by SugarCRM" and "Supercharged by SuiteCRM".
 */

require_once 'modules/UpgradeWizard/UpgradeRemoval.php';

/**
 * Class UpgradeRemoval65x
 */
class UpgradeRemoval65x extends UpgradeRemoval
{
    /**
     * @var string minimal version for removal
     */
    public $version = '6.5.0';

    /**
     * getFilesToRemove
     * Return an array of files/directories to remove for 65x upgrades
     *
     * @param string $version
     *
     * @return array|mixed
     */
    public function getFilesToRemove($version)
    {
        $files = array();


        $files[] = 'include/SugarObjects/templates/company/config.php';
        $files[] = 'include/SugarObjects/templates/sale/config.php';

        $files[] = 'modules/Users/tpls/DetailViewFooter.tpl';
        $files[] = 'modules/Users/tpls/DetailViewHeader.tpl';

	// SuiteCRM 7.8.2
	
	$files[] = 'modules/Users/authentication/SAMLAuthenticate/SAMLAuthenticate.php';
	$files[] = 'modules/Users/authentication/SAMLAuthenticate/SAMLAuthenticateUser.php';
	$files[] = 'modules/Users/authentication/SAMLAuthenticate/index.php';
	$files[] = 'modules/Users/authentication/SAMLAuthenticate/lib/onelogin/saml.php';
	$files[] = 'modules/Users/authentication/SAMLAuthenticate/lib/onelogin/saml/authrequest.php';
	$files[] = 'modules/Users/authentication/SAMLAuthenticate/lib/onelogin/saml/response.php';
	$files[] = 'modules/Users/authentication/SAMLAuthenticate/lib/onelogin/saml/settings.php';
	$files[] = 'modules/Users/authentication/SAMLAuthenticate/lib/onelogin/saml/xmlsec.php';
	$files[] = 'modules/Users/authentication/SAMLAuthenticate/lib/xmlseclibs/CHANGELOG.txt';
	$files[] = 'modules/Users/authentication/SAMLAuthenticate/settings.php';

	// SuiteCRM 7.9.0
		
	$files[] = 'modules/Activities/Popup_picker.html';
	$files[] = 'modules/Emails/DetailView.html';
	$files[] = 'modules/Emails/DetailView.php';
	$files[] = 'modules/Emails/DetailViewSent.html';
	$files[] = 'modules/Emails/EditView.php';
	$files[] = 'modules/Emails/EditViewArchive.html';
	$files[] = 'modules/Emails/ListViewDrafts.html';
	$files[] = 'modules/Emails/ListViewGroup.php';
	$files[] = 'modules/Emails/ListViewGroupInbox.html';
	$files[] = 'modules/Emails/ListViewHome.html';
	$files[] = 'modules/Emails/ListViewHome.php';
	$files[] = 'modules/Emails/ListViewMyInbox.html';
	$files[] = 'modules/Emails/ListViewSent.html';
	$files[] = 'modules/Emails/MassDelete.php';
	$files[] = 'modules/Emails/SearchForm.html';
	$files[] = 'modules/Emails/SearchFormGroupInbox.html';
	$files[] = 'modules/Emails/SearchFormMyInbox.html';
	$files[] = 'modules/Emails/SearchFormSent.html';
	$files[] = 'modules/Emails/SubPanelViewRecipients.html';
	$files[] = 'modules/Emails/SubPanelViewRecipients.php';
	$files[] = 'modules/Emails/images/autofit.gif';
	$files[] = 'modules/Emails/images/colsView.gif';
	$files[] = 'modules/Emails/images/email.gif';
	$files[] = 'modules/Emails/images/emailGroup.gif';
	$files[] = 'modules/Emails/images/fullscreen.gif';
	$files[] = 'modules/Emails/images/leftarrow_inline.gif';
	$files[] = 'modules/Emails/images/rightarrow_inline.gif';
	$files[] = 'modules/Emails/images/rowsView.gif';
	$files[] = 'modules/Emails/images/sugar.gif';
	$files[] = 'modules/Emails/images/sugarDynamic.gif';
	$files[] = 'modules/Emails/images/sugarGroup.gif';
	$files[] = 'modules/Emails/index.php';
	$files[] = 'modules/Emails/templates/_blank.html';
	$files[] = 'modules/Emails/views/view.classic.config.php';
	$files[] = 'modules/Emails/views/view.modulelistmenu.php';
	$files[] = 'modules/Emails/views/view.quickcreate.php';

	// SuiteCRM 7.9.1

	$files[] = 'modules/jjwg_Maps/views/view.donate.php';

	// Security Fix 15/06/2017

	$files[] = 'testinstall.php';

	// SuiteCRM 7.9.2
	
	$files[] = 'modules/Activities/OpenListView.php';
	$files[] = 'modules/Studio/language/en_us.Portal.html';

	// SuiteCRM 7.9.3
	
	$files[] = 'modules/Calendar/Dashlets/CalendarDashlet/CalendarDashlet.ru_ru.lang.php';
	$files[] = 'modules/Calendar/Dashlets/CalendarDashlet/CalendarDashlet.es_es.lang.php';

        // SuiteCRM 7.9.5
        
        $files[] = 'include/javascript/tiny_mce/classes/AddOnManager.js';
        $files[] = 'include/javascript/tiny_mce/classes/ControlManager.js';
        $files[] = 'include/javascript/tiny_mce/classes/Editor.Events.js';
        $files[] = 'include/javascript/tiny_mce/classes/Editor.js';
        $files[] = 'include/javascript/tiny_mce/classes/EditorCommands.js';
        $files[] = 'include/javascript/tiny_mce/classes/EditorManager.js';
        $files[] = 'include/javascript/tiny_mce/classes/EnterKey.js';
        $files[] = 'include/javascript/tiny_mce/classes/ForceBlocks.js';
        $files[] = 'include/javascript/tiny_mce/classes/Formatter.js';
        $files[] = 'include/javascript/tiny_mce/classes/LegacyInput.js';
        $files[] = 'include/javascript/tiny_mce/classes/Popup.js';
        $files[] = 'include/javascript/tiny_mce/classes/UndoManager.js';
        $files[] = 'include/javascript/tiny_mce/classes/WindowManager.js';
        $files[] = 'include/javascript/tiny_mce/classes/adapter/jquery/adapter.js';
        $files[] = 'include/javascript/tiny_mce/classes/adapter/jquery/jquery.tinymce.js';
        $files[] = 'include/javascript/tiny_mce/classes/adapter/prototype/adapter.js';
        $files[] = 'include/javascript/tiny_mce/classes/dom/DOMUtils.js';
        $files[] = 'include/javascript/tiny_mce/classes/dom/Element.js';
        $files[] = 'include/javascript/tiny_mce/classes/dom/EventUtils.js';
        $files[] = 'include/javascript/tiny_mce/classes/dom/Range.js';
        $files[] = 'include/javascript/tiny_mce/classes/dom/RangeUtils.js';
        $files[] = 'include/javascript/tiny_mce/classes/dom/ScriptLoader.js';
        $files[] = 'include/javascript/tiny_mce/classes/dom/Selection.js';
        $files[] = 'include/javascript/tiny_mce/classes/dom/Serializer.js';
        $files[] = 'include/javascript/tiny_mce/classes/dom/Sizzle.js';
        $files[] = 'include/javascript/tiny_mce/classes/dom/TreeWalker.js';
        $files[] = 'include/javascript/tiny_mce/classes/dom/TridentSelection.js';
        $files[] = 'include/javascript/tiny_mce/classes/firebug/FIREBUG.LICENSE';
        $files[] = 'include/javascript/tiny_mce/classes/firebug/firebug-lite.js';
        $files[] = 'include/javascript/tiny_mce/classes/html/DomParser.js';
        $files[] = 'include/javascript/tiny_mce/classes/html/Entities.js';
        $files[] = 'include/javascript/tiny_mce/classes/html/Node.js';
        $files[] = 'include/javascript/tiny_mce/classes/html/SaxParser.js';
        $files[] = 'include/javascript/tiny_mce/classes/html/Schema.js';
        $files[] = 'include/javascript/tiny_mce/classes/html/Serializer.js';
        $files[] = 'include/javascript/tiny_mce/classes/html/Styles.js';
        $files[] = 'include/javascript/tiny_mce/classes/html/Writer.js';
        $files[] = 'include/javascript/tiny_mce/classes/tinymce.js';
        $files[] = 'include/javascript/tiny_mce/classes/ui/Button.js';
        $files[] = 'include/javascript/tiny_mce/classes/ui/ColorSplitButton.js';
        $files[] = 'include/javascript/tiny_mce/classes/ui/Container.js';
        $files[] = 'include/javascript/tiny_mce/classes/ui/Control.js';
        $files[] = 'include/javascript/tiny_mce/classes/ui/DropMenu.js';
        $files[] = 'include/javascript/tiny_mce/classes/ui/KeyboardNavigation.js';
        $files[] = 'include/javascript/tiny_mce/classes/ui/ListBox.js';
        $files[] = 'include/javascript/tiny_mce/classes/ui/Menu.js';
        $files[] = 'include/javascript/tiny_mce/classes/ui/MenuButton.js';
        $files[] = 'include/javascript/tiny_mce/classes/ui/MenuItem.js';
        $files[] = 'include/javascript/tiny_mce/classes/ui/NativeListBox.js';
        $files[] = 'include/javascript/tiny_mce/classes/ui/Separator.js';
        $files[] = 'include/javascript/tiny_mce/classes/ui/SplitButton.js';
        $files[] = 'include/javascript/tiny_mce/classes/ui/Toolbar.js';
        $files[] = 'include/javascript/tiny_mce/classes/ui/ToolbarGroup.js';
        $files[] = 'include/javascript/tiny_mce/classes/util/Cookie.js';
        $files[] = 'include/javascript/tiny_mce/classes/util/Dispatcher.js';
        $files[] = 'include/javascript/tiny_mce/classes/util/JSON.js';
        $files[] = 'include/javascript/tiny_mce/classes/util/JSONP.js';
        $files[] = 'include/javascript/tiny_mce/classes/util/JSONRequest.js';
        $files[] = 'include/javascript/tiny_mce/classes/util/Quirks.js';
        $files[] = 'include/javascript/tiny_mce/classes/util/URI.js';
        $files[] = 'include/javascript/tiny_mce/classes/util/VK.js';
        $files[] = 'include/javascript/tiny_mce/classes/util/XHR.js';
        $files[] = 'include/javascript/tiny_mce/jquery.tinymce.js';
        $files[] = 'include/javascript/tiny_mce/tiny_mce_dev.js';
        $files[] = 'include/javascript/tiny_mce/tiny_mce_jquery.js';
        $files[] = 'include/javascript/tiny_mce/tiny_mce_jquery_src.js';
        $files[] = 'include/javascript/tiny_mce/tiny_mce_prototype.js';
        $files[] = 'include/javascript/tiny_mce/tiny_mce_prototype_src.js';
        $files[] = 'include/javascript/yui/build/yuiloader/yuiloader.js';
        $files[] = 'include/javascript/yui/ext/yui-ext.js';

	
	// SuiteCRM 7.9.7
	
	$files[] = 'install/confirmSettings.php';
	$files[] = 'install/download_patches.php';
	$files[] = 'install/systemOptions.php';

        
        // SuiteCRM 7.9.14
        
        $files[] = 'modules/Administration/SupportPortal.php';
        $files[] = 'modules/Administration/SupportPortal.tpl';
        $files[] = 'modules/Home/TrainingPortal.php';
        $files[] = 'modules/Home/TrainingPortal.tpl';


        // SuiteCRM 7.9.16
         $files[] = 'modules/jjwg_Maps/DataTables/license-gpl2.txt';
         $files[] = 'modules/jjwg_Maps/DataTables/component.txt';
         $files[] = 'modules/jjwg_Maps/DataTables/Readme.txt';
         $files[] = 'modules/jjwg_Maps/DataTables/license-bsd.txt';
         $files[] = 'modules/jjwg_Maps/DataTables/package.txt';
return $files;
}
}