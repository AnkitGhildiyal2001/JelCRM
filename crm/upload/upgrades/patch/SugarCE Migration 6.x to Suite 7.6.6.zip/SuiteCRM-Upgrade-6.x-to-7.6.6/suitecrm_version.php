<?php
 if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

$suitecrm_version      = '7.6.6';
$suitecrm_timestamp    = '2016-07-18 17:00';
