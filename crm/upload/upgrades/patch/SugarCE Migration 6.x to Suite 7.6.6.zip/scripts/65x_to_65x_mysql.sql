ALTER TABLE aor_fields CHANGE function field_function VARCHAR( 100 );
