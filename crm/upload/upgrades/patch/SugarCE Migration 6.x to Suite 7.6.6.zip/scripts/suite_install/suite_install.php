<?php

require_once('sugar_version.php');
require_once('data/BeanFactory.php');

_logThis("Upgrading Config to SuiteCRM Defaults");
global $sugar_config, $db;
$sugar_config['default_max_tabs'] = 10;
$sugar_config['suitecrm_version'] = '7.5.3';
$sugar_config['sugar_version'] = $sugar_version;
$sugar_config['default_theme'] = 'SuiteR';
$sugar_config['sugarbeet'] = false;

ksort($sugar_config);
write_array_to_file('sugar_config', $sugar_config, 'config.php');
_logThis("Finished Upgrading Config to SuiteCRM Defaults");

_logThis("Disabling Check for Sugar updates");
require_once('modules/Administration/updater_utils.php');
set_CheckUpdates_config_setting('manual');
_logThis("Finished Disabling Check for Sugar updates");

_logThis("Updating Default theme for all Users");
require_once('modules/Users/User.php');
$query = "SELECT id FROM users WHERE deleted = 0";
$result = $db->query($query, true, "Unable to update User prefs");
while ($row = $db->fetchByAssoc($result)) {

    $current_user = new User();
    $current_user->retrieve($row['id']);
    $current_user->setPreference('user_theme', 'SuiteR');
    $current_user->setPreference('max_tabs', '10');
    $current_user->savePreferencesToDB();

}
_logThis("Finished Updating Default theme for all Users");

_logThis("Installing SuiteCRM modules");
require_once(clean_path($unzip_dir . '/scripts/suite_install/AdvancedOpenSales.php'));
upgrade_aos();
install_aos();

require_once(clean_path($unzip_dir . '/scripts/suite_install/AdvancedOpenPortal.php'));
install_aop();

require_once(clean_path($unzip_dir . '/scripts/suite_install/AdvancedOpenEvents.php'));
install_aoe();

require_once(clean_path($unzip_dir . '/scripts/suite_install/Projects.php'));
install_projects();

require_once(clean_path($unzip_dir . '/scripts/suite_install/Reschedule.php'));
install_reschedule();

require_once(clean_path($unzip_dir . '/scripts/suite_install/GoogleMaps.php'));
install_gmaps();

require_once(clean_path($unzip_dir . '/scripts/suite_install/Social.php'));
install_social();

require_once(clean_path($unzip_dir . '/scripts/suite_install/suite_schedulers.php'));
install_suite_schedulers();

require_once(clean_path($unzip_dir . '/scripts/suite_install/SecurityGroups.php'));
install_ss();

require_once(clean_path($unzip_dir . '/scripts/suite_install/AdvancedOpenDiscovery.php'));
install_aod();

$installed_modules = array();
$installed_modules[] = 'AOS_Quotes';
$installed_modules[] = 'AOS_Invoices';
$installed_modules[] = 'AOS_Contracts';
$installed_modules[] = 'AM_ProjectTemplates';
$installed_modules[] = 'AM_TaskTemplates';
$installed_modules[] = 'FP_events';
$installed_modules[] = 'FP_Event_Locations';
$installed_modules[] = 'AOS_Products';
$installed_modules[] = 'AOS_Product_Categories';
$installed_modules[] = 'AOS_PDF_Templates';
$installed_modules[] = 'jjwg_Maps';
$installed_modules[] = 'jjwg_Markers';
$installed_modules[] = 'jjwg_Areas';
$installed_modules[] = 'AOR_Reports';
$installed_modules[] = 'AOW_WorkFlow';
$installed_modules[] = 'AOK_KnowledgeBase';
$installed_modules[] = 'AOK_Knowledge_Base_Categories';

include_once('ModuleInstall/ModuleInstaller.php');
UpdateSystemTabs('Add', $installed_modules);
_logThis("Finished Installing SuiteCRM modules");

_logThis("Running Repair");
global $current_user;
$current_user->is_admin = 1;
require_once('modules/Administration/QuickRepairAndRebuild.php');
$randc = new RepairAndClear();
$randc->repairAndClearAll(array('clearAll', 'repairDatabase','repairDatabase','repairDatabase'), array(translate('LBL_ALL_MODULES')), true,false);
_logThis("Finished Running Repair");