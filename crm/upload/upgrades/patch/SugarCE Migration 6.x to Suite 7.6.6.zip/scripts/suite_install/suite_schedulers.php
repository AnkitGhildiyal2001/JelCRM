<?php

function install_suite_schedulers()
{
    include_once('install/install_utils.php');
    require_once('modules/Schedulers/Scheduler.php');

    $mod_strings = return_module_language($GLOBALS['current_language'], 'Schedulers');

    $sched1 = new Scheduler();
    $sched1->retrieve_by_string_fields(array('job' => 'function::processAOW_Workflow'));
    if($sched1->id == '') {
        $sched1->name = $mod_strings['LBL_OOTB_WORKFLOW'];
        $sched1->job = 'function::processAOW_Workflow';
        $sched1->date_time_start = create_date(2016, 1, 1) . ' ' . create_time(0, 0, 1);
        $sched1->date_time_end = null;
        $sched1->job_interval = '*::*::*::*::*';
        $sched1->status = 'Active';
        $sched1->created_by = '1';
        $sched1->modified_user_id = '1';
        $sched1->catch_up = '1';
        $sched1->save();
    }

    $sched2 = new Scheduler();
    $sched2->name = $mod_strings['LBL_OOTB_REPORTS'];
    $sched2->job = 'function::aorRunScheduledReports';
    $sched2->date_time_start = create_date(2016, 1, 1) . ' ' . create_time(0, 0, 1);
    $sched2->date_time_end = null;
    $sched2->job_interval = '*::*::*::*::*';
    $sched2->status = 'Active';
    $sched2->created_by = '1';
    $sched2->modified_user_id = '1';
    $sched2->catch_up = '1';
    $sched2->save();

    $sched4 = new Scheduler();
    $sched4->name = $mod_strings['LBL_OOTB_IE'];
    $sched4->job = 'function::pollMonitoredInboxesAOP';
    $sched4->date_time_start = create_date(2016, 1, 1) . ' ' . create_time(0, 0, 1);
    $sched4->date_time_end = null;
    $sched4->job_interval = '*::*::*::*::*';
    $sched4->status = 'Active';
    $sched4->created_by = '1';
    $sched4->modified_user_id = '1';
    $sched4->catch_up = '0';
    $sched4->save();

    $oldSchedules = $sched4->get_full_list('',"job = 'function::pollMonitoredInboxes' OR job = 'function::pollMonitoredInboxesCustomAOP'");

    foreach($oldSchedules as $oldSchedule){
        $oldSchedule->status = "Inactive";
        $oldSchedule->save();
    }


    $sched8 = new Scheduler();
    $sched8->name = $mod_strings['LBL_OOTB_LUCENE_INDEX'];
    $sched8->job = 'function::aodIndexUnindexed';
    $sched8->date_time_start = create_date(2016, 1, 1) . ' ' . create_time(0, 0, 1);
    $sched8->date_time_end = null;
    $sched8->job_interval = "0::0::*::*::*";
    $sched8->status = 'Active';
    $sched8->created_by = '1';
    $sched8->modified_user_id = '1';
    $sched8->catch_up = '0';
    $sched8->save();

    $sched9 = new Scheduler();
    $sched9->name = $mod_strings['LBL_OOTB_OPTIMISE_INDEX'];
    $sched9->job = 'function::aodOptimiseIndex';
    $sched9->date_time_start = create_date(2016, 1, 1) . ' ' . create_time(0, 0, 1);
    $sched9->date_time_end = null;
    $sched9->job_interval = "0::*/3::*::*::*";
    $sched9->status = 'Active';
    $sched9->created_by = '1';
    $sched9->modified_user_id = '1';
    $sched9->catch_up = '0';
    $sched9->save();

}