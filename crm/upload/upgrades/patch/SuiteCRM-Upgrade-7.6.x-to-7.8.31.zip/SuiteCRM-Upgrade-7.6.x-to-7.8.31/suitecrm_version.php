<?php
if (!defined('sugarEntry') || !sugarEntry) {
    die('Not A Valid Entry Point');
}

$suitecrm_version      = '7.8.31';
$suitecrm_timestamp    = '2019-07-01 17:00:00';
