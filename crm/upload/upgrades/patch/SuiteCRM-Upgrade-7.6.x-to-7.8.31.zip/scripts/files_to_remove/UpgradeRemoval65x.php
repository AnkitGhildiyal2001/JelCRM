<?php
/**
 *
 * SugarCRM Community Edition is a customer relationship management program developed by
 * SugarCRM, Inc. Copyright (C) 2004-2013 SugarCRM Inc.
 *
 * SuiteCRM is an extension to SugarCRM Community Edition developed by SalesAgility Ltd.
 * Copyright (C) 2011 - 2017 SalesAgility Ltd.
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by the
 * Free Software Foundation with the addition of the following permission added
 * to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED WORK
 * IN WHICH THE COPYRIGHT IS OWNED BY SUGARCRM, SUGARCRM DISCLAIMS THE WARRANTY
 * OF NON INFRINGEMENT OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU Affero General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License along with
 * this program; if not, see http://www.gnu.org/licenses or write to the Free
 * Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
 * 02110-1301 USA.
 *
 * You can contact SugarCRM, Inc. headquarters at 10050 North Wolfe Road,
 * SW2-130, Cupertino, CA 95014, USA. or at email address contact@sugarcrm.com.
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License version 3,
 * these Appropriate Legal Notices must retain the display of the "Powered by
 * SugarCRM" logo and "Supercharged by SuiteCRM" logo. If the display of the logos is not
 * reasonably feasible for  technical reasons, the Appropriate Legal Notices must
 * display the words  "Powered by SugarCRM" and "Supercharged by SuiteCRM".
 */

require_once 'modules/UpgradeWizard/UpgradeRemoval.php';

/**
 * Class UpgradeRemoval65x
 */
class UpgradeRemoval65x extends UpgradeRemoval
{
    /**
     * @var string minimal version for removal
     */
    public $version = '6.5.0';

    /**
     * getFilesToRemove
     * Return an array of files/directories to remove for 65x upgrades
     *
     * @param string $version
     *
     * @return array|mixed
     */
    public function getFilesToRemove($version)
    {
        $files = array();

	    $files[] = 'data/Tracker.php';
	    $files[] = 'include/SugarObjects/templates/company/config.php';
	    $files[] = 'include/SugarObjects/templates/sale/config.php';
	    $files[] = 'include/javascript/yui/build/charts/assets/charts.swf';
	    $files[] = 'include/javascript/yui/build/charts/charts-min.js';
	    $files[] = 'include/javascript/yui/build/charts/charts.js';
	    $files[] = 'include/javascript/yui/build/swfstore/swfstore-min.js';
	    $files[] = 'include/javascript/yui/build/swfstore/swfstore.js';
	    $files[] = 'include/javascript/yui/build/swfstore/swfstore.swf';
	    $files[] = 'include/javascript/yui/build/uploader/assets/uploader.swf';
	    $files[] = 'include/javascript/yui/build/uploader/uploader-min.js';
	    $files[] = 'include/javascript/yui/build/uploader/uploader.js';
	    $files[] = 'install/status.json';
	    $files[] = 'modules/AOP_Case_Events/AOP_Case_Events_sugar.php';
	    $files[] = 'modules/AOP_Case_Updates/AOP_Case_Updates_sugar.php';
	    $files[] = 'modules/Calendar/Cal.css';
	    $files[] = 'modules/Favorites/Favorites_sugar.php';
	    $files[] = 'modules/Favorites/Menu.php';
	    $files[] = 'modules/Favorites/favorites_hooks.php';
	    $files[] = 'modules/Favorites/views/view.detail.php';
	    $files[] = 'modules/Favorites/views/view.edit.php';
	    $files[] = 'modules/Home/about.js';
	    $files[] = 'modules/TemplateSectionLine/Dashlets/TemplateSectionLineDashlet/TemplateSectionLineDashlet.meta.php';
	    $files[] = 'modules/TemplateSectionLine/Dashlets/TemplateSectionLineDashlet/TemplateSectionLineDashlet.php';
	    $files[] = 'modules/TemplateSectionLine/metadata/studio.php';
	    $files[] = 'modules/UpgradeWizard/populateColumns.php';
	    $files[] = 'modules/jjwg_Address_Cache/Dashlets/jjwg_Address_CacheDashlet/jjwg_Address_CacheDashlet.meta.php';
	    $files[] = 'modules/jjwg_Address_Cache/Dashlets/jjwg_Address_CacheDashlet/jjwg_Address_CacheDashlet.php';
	    $files[] = 'service/core/REST/SugarRestSerialize.php';
	    $files[] = 'themes/default/images/icon_jjwg_Maps.gif';
	    $files[] = 'themes/default/images/icon_jjwg_Maps.png';

	    $files[] = 'themes/default/images/cmpwzrd/permission.txt';

        $files[] = 'modules/Users/tpls/DetailViewFooter.tpl';
        $files[] = 'modules/Users/tpls/DetailViewHeader.tpl';

	// SuiteCRM 7.8.2
	
	$files[] = 'modules/Users/authentication/SAMLAuthenticate/SAMLAuthenticate.php';
	$files[] = 'modules/Users/authentication/SAMLAuthenticate/SAMLAuthenticateUser.php';
	$files[] = 'modules/Users/authentication/SAMLAuthenticate/index.php';
	$files[] = 'modules/Users/authentication/SAMLAuthenticate/lib/onelogin/saml.php';
	$files[] = 'modules/Users/authentication/SAMLAuthenticate/lib/onelogin/saml/authrequest.php';
	$files[] = 'modules/Users/authentication/SAMLAuthenticate/lib/onelogin/saml/response.php';
	$files[] = 'modules/Users/authentication/SAMLAuthenticate/lib/onelogin/saml/settings.php';
	$files[] = 'modules/Users/authentication/SAMLAuthenticate/lib/onelogin/saml/xmlsec.php';
	$files[] = 'modules/Users/authentication/SAMLAuthenticate/lib/xmlseclibs/CHANGELOG.txt';
	$files[] = 'modules/Users/authentication/SAMLAuthenticate/settings.php';

	// SuiteCRM 7.8.5
	$files[] = 'modules/jjwg_Maps/views/view.donate.php';
	
    // Security fix: 15/6/17
    $files[] = 'testinstall.php';

	// SuiteCRM 7.8.6
        $files[] = 'include/javascript/tiny_mce/classes/AddOnManager.js';
        $files[] = 'include/javascript/tiny_mce/classes/ControlManager.js';
        $files[] = 'include/javascript/tiny_mce/classes/Editor.Events.js';
        $files[] = 'include/javascript/tiny_mce/classes/Editor.js';
        $files[] = 'include/javascript/tiny_mce/classes/EditorCommands.js';
        $files[] = 'include/javascript/tiny_mce/classes/EditorManager.js';
        $files[] = 'include/javascript/tiny_mce/classes/EnterKey.js';
        $files[] = 'include/javascript/tiny_mce/classes/ForceBlocks.js';
        $files[] = 'include/javascript/tiny_mce/classes/Formatter.js';
        $files[] = 'include/javascript/tiny_mce/classes/LegacyInput.js';
        $files[] = 'include/javascript/tiny_mce/classes/Popup.js';
        $files[] = 'include/javascript/tiny_mce/classes/UndoManager.js';
        $files[] = 'include/javascript/tiny_mce/classes/WindowManager.js';
        $files[] = 'include/javascript/tiny_mce/classes/adapter/jquery/adapter.js';
        $files[] = 'include/javascript/tiny_mce/classes/adapter/jquery/jquery.tinymce.js';
        $files[] = 'include/javascript/tiny_mce/classes/adapter/prototype/adapter.js';
        $files[] = 'include/javascript/tiny_mce/classes/dom/DOMUtils.js';
        $files[] = 'include/javascript/tiny_mce/classes/dom/Element.js';
        $files[] = 'include/javascript/tiny_mce/classes/dom/EventUtils.js';
        $files[] = 'include/javascript/tiny_mce/classes/dom/Range.js';
        $files[] = 'include/javascript/tiny_mce/classes/dom/RangeUtils.js';
        $files[] = 'include/javascript/tiny_mce/classes/dom/ScriptLoader.js';
        $files[] = 'include/javascript/tiny_mce/classes/dom/Selection.js';
        $files[] = 'include/javascript/tiny_mce/classes/dom/Serializer.js';
        $files[] = 'include/javascript/tiny_mce/classes/dom/Sizzle.js';
        $files[] = 'include/javascript/tiny_mce/classes/dom/TreeWalker.js';
        $files[] = 'include/javascript/tiny_mce/classes/dom/TridentSelection.js';
        $files[] = 'include/javascript/tiny_mce/classes/firebug/FIREBUG.LICENSE';
        $files[] = 'include/javascript/tiny_mce/classes/firebug/firebug-lite.js';
        $files[] = 'include/javascript/tiny_mce/classes/html/DomParser.js';
        $files[] = 'include/javascript/tiny_mce/classes/html/Entities.js';
        $files[] = 'include/javascript/tiny_mce/classes/html/Node.js';
        $files[] = 'include/javascript/tiny_mce/classes/html/SaxParser.js';
        $files[] = 'include/javascript/tiny_mce/classes/html/Schema.js';
        $files[] = 'include/javascript/tiny_mce/classes/html/Serializer.js';
        $files[] = 'include/javascript/tiny_mce/classes/html/Styles.js';
        $files[] = 'include/javascript/tiny_mce/classes/html/Writer.js';
        $files[] = 'include/javascript/tiny_mce/classes/tinymce.js';
        $files[] = 'include/javascript/tiny_mce/classes/ui/Button.js';
        $files[] = 'include/javascript/tiny_mce/classes/ui/ColorSplitButton.js';
        $files[] = 'include/javascript/tiny_mce/classes/ui/Container.js';
        $files[] = 'include/javascript/tiny_mce/classes/ui/Control.js';
        $files[] = 'include/javascript/tiny_mce/classes/ui/DropMenu.js';
        $files[] = 'include/javascript/tiny_mce/classes/ui/KeyboardNavigation.js';
        $files[] = 'include/javascript/tiny_mce/classes/ui/ListBox.js';
        $files[] = 'include/javascript/tiny_mce/classes/ui/Menu.js';
        $files[] = 'include/javascript/tiny_mce/classes/ui/MenuButton.js';
        $files[] = 'include/javascript/tiny_mce/classes/ui/MenuItem.js';
        $files[] = 'include/javascript/tiny_mce/classes/ui/NativeListBox.js';
        $files[] = 'include/javascript/tiny_mce/classes/ui/Separator.js';
        $files[] = 'include/javascript/tiny_mce/classes/ui/SplitButton.js';
        $files[] = 'include/javascript/tiny_mce/classes/ui/Toolbar.js';
        $files[] = 'include/javascript/tiny_mce/classes/ui/ToolbarGroup.js';
        $files[] = 'include/javascript/tiny_mce/classes/util/Cookie.js';
        $files[] = 'include/javascript/tiny_mce/classes/util/Dispatcher.js';
        $files[] = 'include/javascript/tiny_mce/classes/util/jsON.js';
        $files[] = 'include/javascript/tiny_mce/classes/util/jsONP.js';
        $files[] = 'include/javascript/tiny_mce/classes/util/jsONRequest.js';
        $files[] = 'include/javascript/tiny_mce/classes/util/Quirks.js';
        $files[] = 'include/javascript/tiny_mce/classes/util/URI.js';
        $files[] = 'include/javascript/tiny_mce/classes/util/VK.js';
        $files[] = 'include/javascript/tiny_mce/classes/util/XHR.js';
        $files[] = 'include/javascript/tiny_mce/jquery.tinymce.js';
        $files[] = 'include/javascript/tiny_mce/tiny_mce_dev.js';
        $files[] = 'include/javascript/tiny_mce/tiny_mce_jquery.js';
        $files[] = 'include/javascript/tiny_mce/tiny_mce_jquery_src.js';
        $files[] = 'include/javascript/tiny_mce/tiny_mce_prototype.js';
        $files[] = 'include/javascript/tiny_mce/tiny_mce_prototype_src.js';
        $files[] = 'include/javascript/yui/build/yuiloader/yuiloader.js';
        $files[] = 'include/javascript/yui/ext/yui-ext.js';

	// SuiteCRM 7.8.8

	$files[] = 'install/confirmSettings.php';
	$files[] = 'install/download_patches.php';
	$files[] = 'install/systemOptions.php';
        
        // SuiteCRM 7.8.16

        $files[] = 'modules/Administration/SupportPortal.php';
        $files[] = 'modules/Administration/SupportPortal.tpl';
        $files[] = 'modules/Home/TrainingPortal.php';
        $files[] = 'modules/Home/TrainingPortal.tpl';


        // SuiteCRM 7.8.17
         $files[] = 'modules/jjwg_Maps/DataTables/license-gpl2.txt';
         $files[] = 'modules/jjwg_Maps/DataTables/component.txt';
         $files[] = 'modules/jjwg_Maps/DataTables/Readme.txt';


        // SuiteCRM 7.8.20
         $files[] = 'modules/InboundEmail/InboundEmailTest.php';
         $files[] = '.git/objects/pack/pack-fc435a337bb287c80b7f35ec7d00e092254dd564.idx';
         $files[] = '.git/objects/pack/pack-fc435a337bb287c80b7f35ec7d00e092254dd564.pack';
         $files[] = 'themes/SuiteP/images/sidebar/modules/Emails';
         $files[] = 'themes/SuiteP/images/sub_panel/Email_Marketing2.svg';
         $files[] = 'themes/SuiteP/images/sub_panel/Email_Marketing.svg';
         $files[] = 'themes/SuiteP/images/sub_panel/Email_Marketing.png';
         $files[] = 'themes/SuiteP/images/sub_panel/Email_Marketing2.png';

	// 7.6.x -> 7.8.23
         $files[] = 'include/images/1.gif';
         $files[] = 'include/javascript/tiny_mce/classes/AddOnManager.js';
         $files[] = 'include/javascript/tiny_mce/classes/ControlManager.js';
         $files[] = 'include/javascript/tiny_mce/classes/Editor.Events.js';
         $files[] = 'include/javascript/tiny_mce/classes/Editor.js';
         $files[] = 'include/javascript/tiny_mce/classes/EditorCommands.js';
         $files[] = 'include/javascript/tiny_mce/classes/EditorManager.js';
         $files[] = 'include/javascript/tiny_mce/classes/EnterKey.js';
         $files[] = 'include/javascript/tiny_mce/classes/ForceBlocks.js';
         $files[] = 'include/javascript/tiny_mce/classes/Formatter.js';
         $files[] = 'include/javascript/tiny_mce/classes/LegacyInput.js';
         $files[] = 'include/javascript/tiny_mce/classes/Popup.js';
         $files[] = 'include/javascript/tiny_mce/classes/UndoManager.js';
         $files[] = 'include/javascript/tiny_mce/classes/WindowManager.js';
         $files[] = 'include/javascript/tiny_mce/classes/adapter/jquery/adapter.js';
         $files[] = 'include/javascript/tiny_mce/classes/adapter/jquery/jquery.tinymce.js';
         $files[] = 'include/javascript/tiny_mce/classes/adapter/prototype/adapter.js';
         $files[] = 'include/javascript/tiny_mce/classes/dom/DOMUtils.js';
         $files[] = 'include/javascript/tiny_mce/classes/dom/Element.js';
         $files[] = 'include/javascript/tiny_mce/classes/dom/EventUtils.js';
         $files[] = 'include/javascript/tiny_mce/classes/dom/Range.js';
         $files[] = 'include/javascript/tiny_mce/classes/dom/RangeUtils.js';
         $files[] = 'include/javascript/tiny_mce/classes/dom/ScriptLoader.js';
         $files[] = 'include/javascript/tiny_mce/classes/dom/Selection.js';
         $files[] = 'include/javascript/tiny_mce/classes/dom/Serializer.js';
         $files[] = 'include/javascript/tiny_mce/classes/dom/Sizzle.js';
         $files[] = 'include/javascript/tiny_mce/classes/dom/TreeWalker.js';
         $files[] = 'include/javascript/tiny_mce/classes/dom/TridentSelection.js';
         $files[] = 'include/javascript/tiny_mce/classes/firebug/FIREBUG.LICENSE';
         $files[] = 'include/javascript/tiny_mce/classes/firebug/firebug-lite.js';
         $files[] = 'include/javascript/tiny_mce/classes/html/DomParser.js';
         $files[] = 'include/javascript/tiny_mce/classes/html/Entities.js';
         $files[] = 'include/javascript/tiny_mce/classes/html/Node.js';
         $files[] = 'include/javascript/tiny_mce/classes/html/SaxParser.js';
         $files[] = 'include/javascript/tiny_mce/classes/html/Schema.js';
         $files[] = 'include/javascript/tiny_mce/classes/html/Serializer.js';
         $files[] = 'include/javascript/tiny_mce/classes/html/Styles.js';
         $files[] = 'include/javascript/tiny_mce/classes/html/Writer.js';
         $files[] = 'include/javascript/tiny_mce/classes/tinymce.js';
         $files[] = 'include/javascript/tiny_mce/classes/ui/Button.js';
         $files[] = 'include/javascript/tiny_mce/classes/ui/ColorSplitButton.js';
         $files[] = 'include/javascript/tiny_mce/classes/ui/Container.js';
         $files[] = 'include/javascript/tiny_mce/classes/ui/Control.js';
         $files[] = 'include/javascript/tiny_mce/classes/ui/DropMenu.js';
         $files[] = 'include/javascript/tiny_mce/classes/ui/KeyboardNavigation.js';
         $files[] = 'include/javascript/tiny_mce/classes/ui/ListBox.js';
         $files[] = 'include/javascript/tiny_mce/classes/ui/Menu.js';
         $files[] = 'include/javascript/tiny_mce/classes/ui/MenuButton.js';
         $files[] = 'include/javascript/tiny_mce/classes/ui/MenuItem.js';
         $files[] = 'include/javascript/tiny_mce/classes/ui/NativeListBox.js';
         $files[] = 'include/javascript/tiny_mce/classes/ui/Separator.js';
         $files[] = 'include/javascript/tiny_mce/classes/ui/SplitButton.js';
         $files[] = 'include/javascript/tiny_mce/classes/ui/Toolbar.js';
         $files[] = 'include/javascript/tiny_mce/classes/ui/ToolbarGroup.js';
         $files[] = 'include/javascript/tiny_mce/classes/util/Cookie.js';
         $files[] = 'include/javascript/tiny_mce/classes/util/Dispatcher.js';
         $files[] = 'include/javascript/tiny_mce/classes/util/JSON.js';
         $files[] = 'include/javascript/tiny_mce/classes/util/JSONP.js';
         $files[] = 'include/javascript/tiny_mce/classes/util/JSONRequest.js';
         $files[] = 'include/javascript/tiny_mce/classes/util/Quirks.js';
         $files[] = 'include/javascript/tiny_mce/classes/util/URI.js';
         $files[] = 'include/javascript/tiny_mce/classes/util/VK.js';
         $files[] = 'include/javascript/tiny_mce/classes/util/XHR.js';
         $files[] = 'include/javascript/tiny_mce/jquery.tinymce.js';
         $files[] = 'include/javascript/tiny_mce/tiny_mce_dev.js';
         $files[] = 'include/javascript/tiny_mce/tiny_mce_jquery.js';
         $files[] = 'include/javascript/tiny_mce/tiny_mce_jquery_src.js';
         $files[] = 'include/javascript/tiny_mce/tiny_mce_prototype.js';
         $files[] = 'include/javascript/tiny_mce/tiny_mce_prototype_src.js';
         $files[] = 'include/javascript/yui/build/yuiloader/yuiloader.js';
         $files[] = 'include/javascript/yui/ext/yui-ext.js';
         $files[] = 'install/confirmSettings.php';
         $files[] = 'install/download_patches.php';
         $files[] = 'install/systemOptions.php';
         $files[] = 'modules/AOP_Case_Events/AOP_Case_Events_sugar.php';
         $files[] = 'modules/AOP_Case_Updates/AOP_Case_Updates_sugar.php';
         $files[] = 'modules/Administration/SupportPortal.php';
         $files[] = 'modules/Calendar/Cal.css';
         $files[] = 'modules/Favorites/Favorites_sugar.php';
         $files[] = 'modules/Favorites/favorites_hooks.php';
         $files[] = 'modules/Favorites/views/view.detail.php';
         $files[] = 'modules/Favorites/views/view.edit.php';
         $files[] = 'modules/Users/authentication/SAMLAuthenticate/SAMLAuthenticate.php';
         $files[] = 'modules/Users/authentication/SAMLAuthenticate/SAMLAuthenticateUser.php';
         $files[] = 'modules/Users/authentication/SAMLAuthenticate/index.php';
         $files[] = 'modules/Users/authentication/SAMLAuthenticate/lib/onelogin/saml.php';
         $files[] = 'modules/Users/authentication/SAMLAuthenticate/lib/onelogin/saml/authrequest.php';
         $files[] = 'modules/Users/authentication/SAMLAuthenticate/lib/onelogin/saml/response.php';
         $files[] = 'modules/Users/authentication/SAMLAuthenticate/lib/onelogin/saml/settings.php';
         $files[] = 'modules/Users/authentication/SAMLAuthenticate/lib/onelogin/saml/xmlsec.php';
         $files[] = 'modules/Users/authentication/SAMLAuthenticate/settings.php';
         $files[] = 'modules/Users/tpls/DetailViewFooter.tpl';
         $files[] = 'modules/Users/tpls/DetailViewHeader.tpl';
         $files[] = 'modules/jjwg_Address_Cache/Dashlets/jjwg_Address_CacheDashlet/jjwg_Address_CacheDashlet.meta.php';
         $files[] = 'modules/jjwg_Address_Cache/Dashlets/jjwg_Address_CacheDashlet/jjwg_Address_CacheDashlet.php';
         $files[] = 'modules/jjwg_Maps/DataTables/Readme.txt';
         $files[] = 'modules/jjwg_Maps/DataTables/component.txt';
         $files[] = 'modules/jjwg_Maps/DataTables/license-bsd.txt';
         $files[] = 'modules/jjwg_Maps/DataTables/license-gpl2.txt';
         $files[] = 'modules/jjwg_Maps/DataTables/package.txt';
         $files[] = 'modules/jjwg_Maps/views/view.donate.php';
         $files[] = 'themes/default/images/cmpwzrd/permission.txt';

return $files;
}
}
