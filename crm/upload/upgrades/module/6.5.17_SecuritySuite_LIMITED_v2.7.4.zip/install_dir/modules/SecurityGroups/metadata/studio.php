<?php
/**
 * This file adds support for studio
 */

?>