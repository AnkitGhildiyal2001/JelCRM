<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
global $app_strings;

$dashletMeta['MessageDashlet'] = array( 
                    'title'       => 'Group Messages', 
                    'description' => 'Collaborate with other members of your group. Great for posting important notices.',
                    'icon'        => 'themes/default/images/icon_JotPad_32.gif',
                    'dynamic_hide' => true,
                    'category'    => 'Module Views');
?>