<?php

$dictionary['securitygroups_contacts'] = array ( ); 

?>
