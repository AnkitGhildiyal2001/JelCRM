<?php

$mod_strings['LBL_DEFAULT'] = 'Standaard';
$mod_strings['LBL_ADD_LAYOUT'] = 'Voeg layout toe';
$mod_strings['LBL_ADD_LAYOUTS'] = 'Voeg layout toe';
$mod_strings['LBL_QUESTION_ADD_LAYOUT'] = 'Kies een Groep layout om toe te voegen.';
$mod_strings['LBL_REMOVE_LAYOUT'] = 'Verwijder Groep layout';

$mod_strings['LBL_SECURITYGROUP'] = 'Security Groep:';
$mod_strings['LBL_COPY_FROM'] = 'Kopieer van:';
$mod_strings['LBL_ADDLAYOUTDONE'] = 'Layout opgeslagen';
$mod_strings['LBL_REMOVELAYOUTDONE'] = 'Layout verwijderd';
$mod_strings['LBL_REMOVE_CONFIRM'] = 'Weet u het zeker?';
$mod_strings['help']['studioWizard']['addLayoutHelp'] = "Om een aangepaste layout voor een Security Groep te maken, selecteer de betreffende Security Groep en kopieer vervolgens een layout om als startpunt te fungeren.";
$mod_strings['LBL_ADD_GROUP_LAYOUT'] = 'Voeg een Security Groep Layout';
