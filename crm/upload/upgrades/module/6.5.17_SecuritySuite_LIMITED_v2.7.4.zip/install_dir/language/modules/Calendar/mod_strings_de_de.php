<?php

$mod_strings['LBL_SECURITYGROUPS'] = 'Benutzerliste nach Berechtigungsgruppen filtern';
?>