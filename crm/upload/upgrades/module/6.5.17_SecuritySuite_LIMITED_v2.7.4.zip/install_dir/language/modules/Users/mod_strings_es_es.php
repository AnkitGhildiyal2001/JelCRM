<?php

$mod_strings['LBL_SECURITYGROUPS_SUBPANEL_TITLE'] = "Grupos de Seguridad";
$mod_strings['LBL_PRIMARY_GROUP'] = "Grupo Principal";
