﻿<?php

$mod_strings['LBL_MANAGE_SECURITYGROUPS_TITLE'] = 'Управління Групами Користувачів';
$mod_strings['LBL_MANAGE_SECURITYGROUPS'] = 'Редактор Груп Користувачів';
$mod_strings['LBL_SECURITYGROUPS'] = 'Групи Користувачів';
$mod_strings['LBL_CONFIG_SECURITYGROUPS_TITLE'] = 'Налаштування Груп Користувачів';
$mod_strings['LBL_CONFIG_SECURITYGROUPS'] = 'Конфігурування налаштувань Груп Користувачів';
$mod_strings['LBL_SECURITYGROUPS'] = 'Групи Користувачів';

$mod_strings['LBL_SECURITYGROUPS_UPGRADE_INFO_TITLE'] = "Отримати всі можливості!";

$mod_strings['LBL_SECURITYGROUPS_UPGRADE_INFO'] = "Почніть вигоду від багатьох функцій, які SecuritySuite Преміум приходять з включаючи швидкої налагодження, для користувача групи макетів, і багато іншого.";

$mod_strings['LBL_SECURITYGROUPS_INFO_TITLE'] = "документація";
$mod_strings['LBL_SECURITYGROUPS_INFO'] = "Дізнайтеся більше про багатьох функцій і опцій, що SecuritySuite поставляється упакованої с.";
$mod_strings['LBL_SECURITYGROUPS_DASHLETPUSH_TITLE'] = "Push Message Dashlet";
$mod_strings['LBL_SECURITYGROUPS_DASHLETPUSH'] = "Push the Message Dashlet to the Home page for all users. This process may take some time to complete depending on the number of users";
$mod_strings['LBL_SECURITYGROUPS_HOOKUP_TITLE'] = "Hookup Module";
$mod_strings['LBL_SECURITYGROUPS_HOOKUP'] = "Hookup Security Suite to work with your custom modules";
$mod_strings['LBL_SECURITYGROUPS_SUGAROUTFITTERS_TITLE'] = "SugarOutfitters.com";
$mod_strings['LBL_SECURITYGROUPS_SUGAROUTFITTERS'] = "Детальніше підібраних рішень для Community Edition.";
$mod_strings['LBL_SECURITYGROUPS_LICENSE_TITLE'] = 'конфігурація Ліцензія';
$mod_strings['LBL_SECURITYGROUPS_LICENSE'] = 'Управління та налаштування ліцензію на цей додаток';?>
