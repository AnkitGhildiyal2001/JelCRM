<?php

$mod_strings['LBL_LIST_NONINHERITABLE'] = "Não Herdável";
$mod_strings['LBL_PRIMARY_GROUP'] = "Grupo Principal";

