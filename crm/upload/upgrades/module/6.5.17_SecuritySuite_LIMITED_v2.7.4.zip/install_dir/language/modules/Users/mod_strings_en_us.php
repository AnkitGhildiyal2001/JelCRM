<?php

$mod_strings['LBL_LIST_NONINHERITABLE'] = "Not Inheritable";
$mod_strings['LBL_PRIMARY_GROUP'] = "Primary Group";
