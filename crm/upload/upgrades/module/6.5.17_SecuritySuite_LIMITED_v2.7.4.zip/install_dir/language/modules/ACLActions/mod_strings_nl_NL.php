<?php

$mod_strings['LBL_ACCESS_GROUP'] = 'Groep';

