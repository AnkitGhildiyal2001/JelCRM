<?php

$mod_strings['LBL_SECURITYGROUPS'] = 'Filter gebruikerslijst op Security Groep';
?>