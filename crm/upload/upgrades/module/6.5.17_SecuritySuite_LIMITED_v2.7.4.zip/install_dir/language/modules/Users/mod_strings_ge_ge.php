<?php

$mod_strings['LBL_LIST_NONINHERITABLE'] = "Nicht vererbbar";
$mod_strings['LBL_PRIMARY_GROUP'] = "Startseite Gruppen";
