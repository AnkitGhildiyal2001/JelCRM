<?php

$mod_strings['LBL_LIST_NONINHERITABLE'] = "Niet Erfbaar";
$mod_strings['LBL_PRIMARY_GROUP'] = "Primaire Groep";
