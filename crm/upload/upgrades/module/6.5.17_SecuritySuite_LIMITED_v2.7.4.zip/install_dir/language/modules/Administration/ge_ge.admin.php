<?php

$mod_strings['LBL_MANAGE_SECURITYGROUPS_TITLE'] = 'Berechtigungsgruppen';
$mod_strings['LBL_MANAGE_SECURITYGROUPS'] = 'Berechtigungsgruppen bearbeiten';
$mod_strings['LBL_SECURITYGROUPS'] = 'Berechtigungsgruppen';
$mod_strings['LBL_CONFIG_SECURITYGROUPS_TITLE'] = 'Berechtigungsgruppen Konfiguration';
$mod_strings['LBL_CONFIG_SECURITYGROUPS'] = 'Konfigurieren Sie die Einstellungen für Berechtigungsgruppen wie zum Beispiel Gruppenvererbung etc.';
$mod_strings['LBL_SECURITYGROUPS'] = 'Berechtigungsgruppen';
$mod_strings['LBL_SECURITYGROUPS_UPGRADE_INFO_TITLE'] = "Jetzt alle Features!";
$mod_strings['LBL_SECURITYGROUPS_UPGRADE_INFO'] = "Starten Sie profitiert von den vielen Funktionen, die Premium-Security kommen mit schnellen einschlie�lich Debugging, benutzerdefinierte Gruppe Layouts und mehr.";
$mod_strings['LBL_SECURITYGROUPS_INFO_TITLE'] = "Dokumentation";
$mod_strings['LBL_SECURITYGROUPS_INFO'] = "Erfahren Sie mehr �ber die vielen Funktionen und Optionen, Security kommt verpackt mit.";
$mod_strings['LBL_SECURITYGROUPS_DASHLETPUSH_TITLE'] = "Dr�cken Sie Mitteilung Dashlet";
$mod_strings['LBL_SECURITYGROUPS_DASHLETPUSH'] = "Dr�cken Sie die Mitteilung Dashlet zum Home Page f�r alle Benutzer. Dieser Prozess kann einige Zeit nehmen, abh�ngig von der Zahl Benutzern abzuschlie�en";
$mod_strings['LBL_SECURITYGROUPS_HOOKUP_TITLE'] = "Ausstrahlung-Modul";
$mod_strings['LBL_SECURITYGROUPS_HOOKUP'] = "Ausstrahlung-Berechtigungsgruppen, zum mit Ihren kundenspezifischen Modulen zu arbeiten";
$mod_strings['LBL_SECURITYGROUPS_SUGAROUTFITTERS_TITLE'] = "SugarOutfitters.com";
$mod_strings['LBL_SECURITYGROUPS_SUGAROUTFITTERS'] = "Weitere handverlesene L�sungen f�r die Community Edition.";
$mod_strings['LBL_SECURITYGROUPS_LICENSE_TITLE'] = 'Lizenzkonfiguration';
$mod_strings['LBL_SECURITYGROUPS_LICENSE'] = 'Verwalten und konfigurieren Sie die Lizenz f�r dieses Modul';
