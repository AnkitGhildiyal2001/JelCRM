﻿<?php

$mod_strings['LBL_MANAGE_SECURITYGROUPS_TITLE'] = 'Biztonsági Csoportok Kezelése';
$mod_strings['LBL_MANAGE_SECURITYGROUPS'] = 'Biztonsági Csoport Szerkesztő';
$mod_strings['LBL_SECURITYGROUPS'] = 'Biztonsági Csoportok';
$mod_strings['LBL_CONFIG_SECURITYGROUPS_TITLE'] = 'Biztonsági Csoportok Beállításai';
$mod_strings['LBL_CONFIG_SECURITYGROUPS'] = 'Módosíthatók a Biztonsági Csoport beállításai, mint pl. az öröklődés, additív jogok, stb.';
$mod_strings['LBL_SECURITYGROUPS'] = 'Biztonsági Csoportok';
$mod_strings['LBL_SECURITYGROUPS_UPGRADE_INFO_TITLE'] = "Get All funkciók!";

$mod_strings['LBL_SECURITYGROUPS_UPGRADE_INFO'] = "Részesüljenek a számos olyan funkciót tartalmaz, amely SecuritySuite Premium jön, beleértve a gyors hibakeresés, egyedi csoport elrendezés, és így tovább.";

$mod_strings['LBL_SECURITYGROUPS_INFO_TITLE'] = "Dokumentáció";
$mod_strings['LBL_SECURITYGROUPS_INFO'] = "Tudjon meg többet a számos funkciók és lehetőségek, amelyek SecuritySuite tele van.";
$mod_strings['LBL_SECURITYGROUPS_DASHLETPUSH_TITLE'] = "Csoportos Üzenet Műszer telepítése";
$mod_strings['LBL_SECURITYGROUPS_DASHLETPUSH'] = "Minden felhasználó kezdőlapjára telepíti a Csoportos Üzenet Műszert. Ez a művelet hoszabb ideig is eltarhat, a felhasználók számától függően.";
$mod_strings['LBL_SECURITYGROUPS_HOOKUP_TITLE'] = "Modul Csatlakoztatása";
$mod_strings['LBL_SECURITYGROUPS_HOOKUP'] = "Biztonsági Csoport képesség hozzáadása egyedi modulhoz";
$mod_strings['LBL_SECURITYGROUPS_SUGAROUTFITTERS_TITLE'] = "SugarOutfitters.com";
$mod_strings['LBL_SECURITYGROUPS_SUGAROUTFITTERS'] = "További válogatott megoldások Community Edition.";
$mod_strings['LBL_SECURITYGROUPS_LICENSE_TITLE'] = 'licenc konfiguráció';
$mod_strings['LBL_SECURITYGROUPS_LICENSE'] = 'Kezelése, és konfigurálja a engedélyt ez a kiegészítő';?>
