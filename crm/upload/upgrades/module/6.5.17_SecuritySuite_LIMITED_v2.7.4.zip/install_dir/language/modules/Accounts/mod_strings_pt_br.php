<?php

$mod_strings['LBL_SECURITYGROUPS_SUBPANEL_TITLE'] = "Grupos de Segurança";

