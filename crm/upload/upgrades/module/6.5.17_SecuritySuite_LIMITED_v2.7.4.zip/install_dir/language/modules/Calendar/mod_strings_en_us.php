<?php

$mod_strings['LBL_SECURITYGROUPS'] = 'Filter user list by Security Group';
?>