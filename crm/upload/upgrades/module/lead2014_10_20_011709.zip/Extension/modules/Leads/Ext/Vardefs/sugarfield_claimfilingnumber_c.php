<?php
 // created: 2014-09-09 10:20:59
$dictionary['Lead']['fields']['claimfilingnumber_c']['labelValue']='Claim Filing Status';

 ?>