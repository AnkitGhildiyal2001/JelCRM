<?php
 // created: 2014-07-28 21:52:55
$dictionary['Lead']['fields']['cases_c']['labelValue']='Cases';

 ?>