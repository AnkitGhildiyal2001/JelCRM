<?php
 // created: 2014-07-28 21:59:12
$dictionary['Lead']['fields']['taxid_c']['labelValue']='Tax ID';

 ?>