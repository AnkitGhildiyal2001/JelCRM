<?php
// created: 2013-12-13 06:59:56
$dictionary["Lead"]["fields"]["pass1_sendinfopack_leads"] = array (
  'name' => 'pass1_sendinfopack_leads',
  'type' => 'link',
  'relationship' => 'pass1_sendinfopack_leads',
  'source' => 'non-db',
  'vname' => 'LBL_PASS1_SENDINFOPACK_LEADS_FROM_PASS1_SENDINFOPACK_TITLE',
);
