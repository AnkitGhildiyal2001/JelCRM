<?php 
 // created: 2014-05-02 13:53:11
$mod_strings['LBL_COMPANYNAME'] = 'Business Name';
$mod_strings['LBL_TAXID'] = 'Tax ID';
$mod_strings['LBL_PANEL_ADVANCED'] = 'Case Information';
$mod_strings['LBL_DBANAME'] = 'DBA Name';
$mod_strings['LBL_OTHERFIRSTNAME'] = 'Alt Contact First Name';
$mod_strings['LBL_OTHERLASTNAME'] = 'Alt Contact Last Name';
$mod_strings['LBL_DESCRIPTION'] = 'Remarks:';
$mod_strings['LBL_LEAD_SOURCE_DESCRIPTION'] = 'Lead Source Remarks:';
$mod_strings['LBL_STATUS'] = 'Lead Status:';
$mod_strings['LBL_STATUS_DESCRIPTION'] = 'Status Remarks:';
$mod_strings['LBL_EDITVIEW_PANEL1'] = 'Alternate Contact Info';
$mod_strings['LBL_FIRST_NAME'] = 'Signer First Name:';
$mod_strings['LBL_LAST_NAME'] = 'Signer Last Name:';
$mod_strings['LBL_POSTAL_CODE'] = 'Zip Code:';
$mod_strings['LBL_INDUSTRY'] = 'Industry';
$mod_strings['LBL_TITLE'] = 'Signer Title:';
$mod_strings['LBL_ALTSIGNERTITLE'] = 'Alt Contact Title';
$mod_strings['LBL_MULTILOCATION'] = 'Multi-Location';
$mod_strings['LBL_MULTITAXID'] = 'Multi-Tax-ID';

?>
