<?php 
 // created: 2014-10-20 01:17:08
$mod_strings['LBL_CASES'] = 'Cases';
$mod_strings['LBL_PASS1_SENDINFOPACK_LEADS_FROM_PASS1_SENDINFOPACK_TITLE'] = 'Send Info Pack';
$mod_strings['LBL_CLAIMFILINGNUMBER'] = 'Claim Filing Status';

?>
