<?php 
$app_list_strings['claimfilingnumber_list'] = array (
  'New' => 'New',
  'ClaimAppliedfor' => 'Claim Applied-for',
  'ClaimInvalid' => 'Claim Invalid',
  'Claimreceived' => 'Claim # received',
  'ClaimPaid' => 'Claim Paid',
);$app_list_strings['cases_list'] = array (
  'Visa' => 'Visa',
  'Freight' => 'Freight Forwarders',
  'Dram' => 'D Ram Indirect',
  'lcd' => 'LCD Indirect',
  'Cathode' => 'Cathode Ray Tube',
  'optical' => 'Optical Disc Drive',
);