<?php 
 // created: 2014-10-18 00:01:39
$mod_strings['LBL_CASEM'] = 'Case';
$mod_strings['LBL_STATEMENTS'] = 'Statements';
$mod_strings['LBL_CLAIMFILINGSTATUS'] = 'Claim Filing Number';
$mod_strings['LBL_ESTCLAIM'] = 'Est Claim';
$mod_strings['LBL_TAXID'] = 'TaxID';
$mod_strings['LBL_VISA'] = 'Visa';
$mod_strings['LBL_LCD'] = 'LCD';
$mod_strings['LBL_FREIGHTFORWARDERS'] = 'Freight Forwarders';
$mod_strings['LBL_DRAM'] = 'DRam';
$mod_strings['LBL_EGGS'] = 'Eggs';
$mod_strings['LBL_EDITVIEW_PANEL1'] = 'undefined 1';
$mod_strings['LBL_EDITVIEW_PANEL2'] = 'undefined 2';
$mod_strings['LBL_EDITVIEW_PANEL3'] = 'Case Info';
$mod_strings['LBL_EDITVIEW_PANEL4'] = 'undefined 4';
$mod_strings['LBL_FIRST_NAME'] = 'Signer First Name';
$mod_strings['LBL_LAST_NAME'] = 'Signer Last Name';
$mod_strings['LBL_PHONE_MOBILE'] = 'phone mobile';
$mod_strings['LBL_PHONE_WORK'] = 'phone work';
$mod_strings['LBL_COMPANYNAME'] = 'Company Name';
$mod_strings['LBL_PASS1_SENDINFOPACK_ACCOUNTS_1_FROM_PASS1_SENDINFOPACK_TITLE'] = 'Send Info Pack';
$mod_strings['LBL_PASS1_SENDINFOPACK_ACCOUNTS_FROM_PASS1_SENDINFOPACK_TITLE'] = 'Send Info Pack';
$mod_strings['LBL_CLAIMSTATUS'] = 'Claim Status';

?>
