<?php 
$app_list_strings['claimstatus_list'] = array (
  'ClaimAppliedfor' => 'Claim Applied-for',
  'New' => 'New',
  'ClaimInvalid' => 'Claim Invalid',
  'Claimreceived' => 'Claim # received',
  'ClaimPaid' => 'Claim Paid',
);