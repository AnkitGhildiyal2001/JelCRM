<?php
 // created: 2014-07-31 18:17:02
$dictionary['Account']['fields']['first_name_c']['labelValue']='Signer First Name';

 ?>