<?php
 // created: 2014-07-31 17:57:45
$dictionary['Account']['fields']['dram_c']['labelValue']='DRam';

 ?>