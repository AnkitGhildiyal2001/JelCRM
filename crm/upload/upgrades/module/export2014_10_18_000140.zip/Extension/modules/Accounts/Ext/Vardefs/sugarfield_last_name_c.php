<?php
 // created: 2014-07-31 18:17:23
$dictionary['Account']['fields']['last_name_c']['labelValue']='Signer Last Name';

 ?>