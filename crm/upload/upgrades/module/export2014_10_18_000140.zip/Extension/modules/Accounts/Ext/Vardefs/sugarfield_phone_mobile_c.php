<?php
 // created: 2014-07-31 18:17:35
$dictionary['Account']['fields']['phone_mobile_c']['labelValue']='phone mobile';

 ?>