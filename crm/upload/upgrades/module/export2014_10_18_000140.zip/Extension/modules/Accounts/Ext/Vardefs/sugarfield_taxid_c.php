<?php
 // created: 2014-07-31 17:56:19
$dictionary['Account']['fields']['taxid_c']['labelValue']='TaxID';

 ?>