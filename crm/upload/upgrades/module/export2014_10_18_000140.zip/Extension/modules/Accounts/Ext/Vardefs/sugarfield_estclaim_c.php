<?php
 // created: 2014-07-31 17:55:44
$dictionary['Account']['fields']['estclaim_c']['labelValue']='Est Claim';

 ?>