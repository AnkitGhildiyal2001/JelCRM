<?php
 // created: 2014-07-31 17:53:55
$dictionary['Account']['fields']['casem_c']['labelValue']='Casem';

 ?>