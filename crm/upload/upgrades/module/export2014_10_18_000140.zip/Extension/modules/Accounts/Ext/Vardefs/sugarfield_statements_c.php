<?php
 // created: 2014-07-31 17:54:19
$dictionary['Account']['fields']['statements_c']['labelValue']='Statements';

 ?>