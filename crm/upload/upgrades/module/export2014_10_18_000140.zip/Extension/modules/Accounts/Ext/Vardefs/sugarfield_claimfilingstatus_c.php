<?php
 // created: 2014-07-31 17:55:07
$dictionary['Account']['fields']['claimfilingstatus_c']['labelValue']='Claim Filing Status';

 ?>