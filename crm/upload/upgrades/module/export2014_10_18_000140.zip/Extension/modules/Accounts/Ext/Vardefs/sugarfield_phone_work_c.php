<?php
 // created: 2014-07-31 18:17:49
$dictionary['Account']['fields']['phone_work_c']['labelValue']='phone work';

 ?>