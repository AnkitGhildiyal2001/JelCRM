<?php
 // created: 2014-07-31 17:57:54
$dictionary['Account']['fields']['eggs_c']['labelValue']='Eggs';

 ?>