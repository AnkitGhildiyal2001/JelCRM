<?php
 // created: 2014-07-31 18:19:47
$dictionary['Account']['fields']['companyname_c']['labelValue']='Company Name';

 ?>