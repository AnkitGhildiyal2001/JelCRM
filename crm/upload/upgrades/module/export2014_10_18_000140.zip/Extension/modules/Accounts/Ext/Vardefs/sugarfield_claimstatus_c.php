<?php
 // created: 2014-08-26 10:36:14
$dictionary['Account']['fields']['claimstatus_c']['labelValue']='Claim Status';

 ?>