<?php
 // created: 2014-07-31 17:57:25
$dictionary['Account']['fields']['freightforwarders_c']['labelValue']='Freight Forwarders';

 ?>