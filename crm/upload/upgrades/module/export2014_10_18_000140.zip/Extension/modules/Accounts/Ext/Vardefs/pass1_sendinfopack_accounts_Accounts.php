<?php
// created: 2013-12-13 06:59:56
$dictionary["Account"]["fields"]["pass1_sendiopack_accounts"] = array (
  'name' => 'pass1_sendiopack_accounts',
  'type' => 'link',
  'relationship' => 'pass1_sendinfopack_accounts',
  'source' => 'non-db',
  'vname' => 'LBL_PASS1_SENDINFOPACK_ACCOUNTS_FROM_PASS1_SENDINFOPACK_TITLE',
);
