<?php
 // created: 2014-07-31 17:56:48
$dictionary['Account']['fields']['visa_c']['labelValue']='Visa';

 ?>